   This repository contains the official experimental codebase for the paper on **Manifold-Constrained Adversarial Training (MCAT)**.


------

   ## 1. Environment Setup

   ### Requirements

   - Python ≥ 3.9
   - PyTorch ≥ 2.0
------

   ## 2. Data Preparation

   ### CIFAR-10 / CIFAR-100 (Long-Tailed)

   - CIFAR datasets are automatically downloaded

   - Long-tailed splits are generated on demand by:

     ```text
     scripts/prepare_cifar_lt.py
     ```
------

   ### TinyImageNet-LT

   We provide a helper script to:
   ```bash
   make data
   ```


------

   ## 4. Train and Eval MCAT


   ```bash
   METHODS="mcat" \
   bash scripts/run_grid.sh cifar100 "10 50 100" "0 1 2"
   ```



