#!/usr/bin/env bash
set -euo pipefail
source tools/env.sh

DATA="${DATA:-data}"
RUNS="${RUNS:-runs}"
DATASET="${DATASET:-cifar100}"
IR="${IR:-100}"
SEED="${SEED:-0}"

ARCH="${ARCH:-resnet18}"
EPOCHS="${EPOCHS:-200}"
BS="${BS:-128}"
LR="${LR:-0.1}"
WD="${WD:-5e-4}"
MOM="${MOM:-0.9}"

EPS="${EPS:-8/255}"
TR_STEPS="${TR_STEPS:-10}"
TR_STEP="${TR_STEP:-2/255}"

EV_PGD_STEPS="${EV_PGD_STEPS:-20}"
EV_PGD_STEP="${EV_PGD_STEP:-2/255}"
EVAL_ATTACK="${EVAL_ATTACK:-aa}"

LAMBDA_M="${LAMBDA_M:-0.2}"
BETA_G="${BETA_G:-1.0}"
MSPGD_STEPS="${MSPGD_STEPS:-10}"
MSPGD_STEP="${MSPGD_STEP:-2/255}"

GEN_Z="${GEN_Z:-64}"
GEN_HID="${GEN_HID:-256,256}"
GEN_EPOCHS="${GEN_EPOCHS:-10}"
GEN_LR="${GEN_LR:-1e-3}"
GEN_BS="${GEN_BS:-256}"
GEN_LAT_STEPS="${GEN_LAT_STEPS:-5}"
GEN_LAT_LR="${GEN_LAT_LR:-0.1}"

EXP_NAME="mcat_${DATASET}_ir${IR}_seed${SEED}"

echo "[run_mcat] DATA=${DATA} RUNS=${RUNS} DATASET=${DATASET} IR=${IR} SEED=${SEED}"
python3 run.py \
  --exp_name "${EXP_NAME}" \
  --run_dir "${RUNS}" \
  --seed "${SEED}" \
  --dataset "${DATASET}" \
  --data_root "${DATA}" \
  --ir "${IR}" \
  --method mcat \
  --arch "${ARCH}" \
  --epochs "${EPOCHS}" \
  --batch_size "${BS}" \
  --lr "${LR}" \
  --weight_decay "${WD}" \
  --momentum "${MOM}" \
  --epsilon "${EPS}" \
  --train_attack_steps "${TR_STEPS}" \
  --train_attack_step_size "${TR_STEP}" \
  --eval_attack "${EVAL_ATTACK}" \
  --eval_pgd_steps "${EV_PGD_STEPS}" \
  --eval_pgd_step_size "${EV_PGD_STEP}" \
  --lambda_m "${LAMBDA_M}" \
  --beta_g "${BETA_G}" \
  --mspgd_steps "${MSPGD_STEPS}" \
  --mspgd_step_size "${MSPGD_STEP}" \
  --gen_z_dim "${GEN_Z}" \
  --gen_hidden "${GEN_HID}" \
  --gen_epochs "${GEN_EPOCHS}" \
  --gen_lr "${GEN_LR}" \
  --gen_batch_size "${GEN_BS}" \
  --gen_latent_steps "${GEN_LAT_STEPS}" \
  --gen_latent_lr "${GEN_LAT_LR}"
