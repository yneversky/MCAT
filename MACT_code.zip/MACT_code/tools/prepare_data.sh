#!/usr/bin/env bash
set -e
source tools/env.sh

DATA_ROOT="${1:-data}"
IR="${IR:-100}"
SEED="${SEED:-0}"

mkdir -p "${DATA_ROOT}"

echo "[data] CIFAR LT splits..."
python scripts/prepare_cifar_lt.py --dataset cifar10  --data_root "${DATA_ROOT}" --ir "${IR}" --seed "${SEED}"
python scripts/prepare_cifar_lt.py --dataset cifar100 --data_root "${DATA_ROOT}" --ir "${IR}" --seed "${SEED}"

echo "[data] Tiny-ImageNet download..."
TINY_URL="${TINY_URL:-http://cs231n.stanford.edu/tiny-imagenet-200.zip}"
TINY_ZIP="${DATA_ROOT}/tiny-imagenet-200.zip"
TINY_ROOT="${DATA_ROOT}/tiny-imagenet-200"

if [ ! -d "${TINY_ROOT}" ]; then
  curl -L -o "${TINY_ZIP}" "${TINY_URL}"
  unzip -q "${TINY_ZIP}" -d "${DATA_ROOT}"
fi

echo "[data] Tiny-ImageNet val_cls..."
python scripts/prepare_tinyimagenet_val.py --tiny_root "${TINY_ROOT}"

echo "[data] Tiny-ImageNet train_lt..."
python scripts/prepare_tinyimagenet_lt.py --tiny_root "${TINY_ROOT}" --ir "${IR}" --seed "${SEED}" --copy_mode copy

echo "OK: data prepared at ${DATA_ROOT}"
