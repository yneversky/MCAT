#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="$ROOT/.venv/bin/python3"

: "${RUN_DIR:=runs}"
: "${OUT_DIR:=runs/report}"

cd "$ROOT"

exec "$PY" run.py \
  --report_only \
  --run_dir "$RUN_DIR" \
  --dataset cifar100 \
  --ir 100
