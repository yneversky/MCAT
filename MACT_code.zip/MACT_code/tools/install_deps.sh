#!/usr/bin/env bash
set -e
source tools/env.sh

python -m pip install -r requirements.txt
python -m pip install -e .
echo "OK: deps installed and project installed editable."
