#!/usr/bin/env bash
set -euo pipefail
source tools/env.sh

DATA="${DATA:-data}"
RUNS="${RUNS:-runs}"
DATASET="${DATASET:-cifar100}"
IR="${IR:-100}"
SEED="${SEED:-0}"

ARCH="${ARCH:-resnet18}"
EPOCHS="${EPOCHS:-200}"
BS="${BS:-128}"
LR="${LR:-0.1}"
WD="${WD:-5e-4}"
MOM="${MOM:-0.9}"

EPS="${EPS:-8/255}"
TR_STEPS="${TR_STEPS:-10}"
TR_STEP="${TR_STEP:-2/255}"

EV_PGD_STEPS="${EV_PGD_STEPS:-20}"
EV_PGD_STEP="${EV_PGD_STEP:-2/255}"
EVAL_ATTACK="${EVAL_ATTACK:-aa}"

AWP_GAMMA="${AWP_GAMMA:-0.01}"
AWP_LR="${AWP_LR:-0.01}"
AWP_STEPS="${AWP_STEPS:-1}"

EXP_NAME="awp_${DATASET}_ir${IR}_seed${SEED}"

echo "[run_awp] DATA=${DATA} RUNS=${RUNS} DATASET=${DATASET} IR=${IR} SEED=${SEED}"
python3 run.py \
  --exp_name "${EXP_NAME}" \
  --run_dir "${RUNS}" \
  --seed "${SEED}" \
  --dataset "${DATASET}" \
  --data_root "${DATA}" \
  --ir "${IR}" \
  --method awp \
  --arch "${ARCH}" \
  --epochs "${EPOCHS}" \
  --batch_size "${BS}" \
  --lr "${LR}" \
  --weight_decay "${WD}" \
  --momentum "${MOM}" \
  --epsilon "${EPS}" \
  --train_attack_steps "${TR_STEPS}" \
  --train_attack_step_size "${TR_STEP}" \
  --eval_attack "${EVAL_ATTACK}" \
  --eval_pgd_steps "${EV_PGD_STEPS}" \
  --eval_pgd_step_size "${EV_PGD_STEP}" \
  --awp_gamma "${AWP_GAMMA}" \
  --awp_lr "${AWP_LR}" \
  --awp_steps "${AWP_STEPS}"
