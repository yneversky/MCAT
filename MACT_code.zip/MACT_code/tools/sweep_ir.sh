#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="$ROOT/.venv/bin/python3"

: "${DATASET:?Need DATASET}"
: "${SEED:?Need SEED}"
: "${DATA_ROOT:=data}"
: "${RUN_DIR:=runs}"
: "${LAMBDA_M:=0.2}"
: "${BETA_G:=1.0}"

cd "$ROOT"

for IR in 10 20 50 100; do
  echo "[sweep] DATASET=$DATASET IR=$IR SEED=$SEED"
  "$PY" run.py \
    --exp_name "mcat_sweep" \
    --dataset "$DATASET" \
    --data_root "$DATA_ROOT" \
    --ir "$IR" \
    --seed "$SEED" \
    --method mcat \
    --eval_attack aa \
    --lambda_m "$LAMBDA_M" \
    --beta_g "$BETA_G"
done
