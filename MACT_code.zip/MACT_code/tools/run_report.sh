#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."


if [ -d ".venv" ]; then
  source .venv/bin/activate
else
  echo "[warn] .venv not found. Using current python environment (OK for Colab)."
fi

RUN_DIR=${1:-runs}
TAG=${TAG:-best}

echo "=============================="
echo " AGGREGATE REPORT"
echo " run_dir=${RUN_DIR}"
echo " tag=${TAG}"
echo "=============================="

python scripts/aggregate_results.py --run_dir "${RUN_DIR}" --tag "${TAG}"

echo "OK: aggregated outputs at: ${RUN_DIR}/aggregate"
ls -la "${RUN_DIR}/aggregate" || true
