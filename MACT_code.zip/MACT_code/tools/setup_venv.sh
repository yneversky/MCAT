#!/usr/bin/env bash
set -e

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 not found."
  exit 1
fi

python3 -m venv .venv
source .venv/bin/activate
python -m pip install -U pip setuptools wheel
echo "OK: .venv created."
