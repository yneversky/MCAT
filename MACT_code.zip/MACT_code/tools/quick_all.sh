#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."

if [ -d ".venv" ]; then
  source .venv/bin/activate
else
  echo "[warn] .venv not found. Using current python environment (OK for Colab)."
fi

DATA_ROOT=${DATA_ROOT:-data}
RUN_DIR=${RUN_DIR:-runs}

DATASET=${1:-cifar10}
IR=${2:-10}
SEEDS=${3:-"0"}

ARCH=${ARCH:-resnet18}
EPOCHS=${EPOCHS:-2}
BS=${BS:-64}

EPS=${EPS:-"8/255"}
ALPHA=${ALPHA:-"2/255"}
TRAIN_STEPS=${TRAIN_STEPS:-2}
EVAL_STEPS=${EVAL_STEPS:-2}
EVAL_MAX_BATCHES=${EVAL_MAX_BATCHES:-2}
SAVE_EVERY=${SAVE_EVERY:-1}

METHODS=${METHODS:-"clean pgd_at trades mart fast_at free_at awp mcat"}

TRADES_BETA=${TRADES_BETA:-6.0}
MART_BETA=${MART_BETA:-6.0}
FAST_ALPHA=${FAST_ALPHA:-0}
FREE_M=${FREE_M:-4}

AWP_GAMMA=${AWP_GAMMA:-0.01}
AWP_LR=${AWP_LR:-0.01}
AWP_STEPS=${AWP_STEPS:-1}

MSPGD_STEPS=${MSPGD_STEPS:-2}
MSPGD_STEP_SIZE=${MSPGD_STEP_SIZE:-"${ALPHA}"}
GEN_EPOCHS=${GEN_EPOCHS:-1}
GEN_LATENT_STEPS=${GEN_LATENT_STEPS:-2}
GEN_LATENT_LR=${GEN_LATENT_LR:-0.1}
LAMBDA_M=${LAMBDA_M:-0.1}
BETA_G=${BETA_G:-0.1}

echo "=============================="
echo " QUICK ALL (tools/quick_all.sh)"
echo " dataset=${DATASET} ir=${IR} seeds=${SEEDS}"
echo " methods=${METHODS}"
echo " epochs=${EPOCHS} bs=${BS}"
echo " eval_max_batches=${EVAL_MAX_BATCHES}"
echo " run_dir=${RUN_DIR} data_root=${DATA_ROOT}"
echo "=============================="

if [[ "${DATASET}" == "cifar10" || "${DATASET}" == "cifar100" ]]; then
  for SEED in ${SEEDS}; do
    python scripts/prepare_cifar_lt.py --data_root "${DATA_ROOT}" --dataset ${DATASET} --ir ${IR} --seed ${SEED} || true
  done
fi

RUN_DIR="${RUN_DIR}" DATA_ROOT="${DATA_ROOT}" METHODS="${METHODS}" \
ARCH="${ARCH}" EPOCHS="${EPOCHS}" BS="${BS}" \
EPS="${EPS}" ALPHA="${ALPHA}" TRAIN_STEPS="${TRAIN_STEPS}" EVAL_STEPS="${EVAL_STEPS}" \
EVAL_ATTACK="pgd20" EVAL_MAX_BATCHES="${EVAL_MAX_BATCHES}" SAVE_EVERY="${SAVE_EVERY}" \
TRADES_BETA="${TRADES_BETA}" MART_BETA="${MART_BETA}" FAST_ALPHA="${FAST_ALPHA}" FREE_M="${FREE_M}" \
AWP_GAMMA="${AWP_GAMMA}" AWP_LR="${AWP_LR}" AWP_STEPS="${AWP_STEPS}" \
MSPGD_STEPS="${MSPGD_STEPS}" MSPGD_STEP_SIZE="${MSPGD_STEP_SIZE}" \
GEN_EPOCHS="${GEN_EPOCHS}" GEN_LATENT_STEPS="${GEN_LATENT_STEPS}" GEN_LATENT_LR="${GEN_LATENT_LR}" \
LAMBDA_M="${LAMBDA_M}" BETA_G="${BETA_G}" \
bash tools/run_grid.sh "${DATASET}" "${IR}" "${SEEDS}"

echo "=============================="
