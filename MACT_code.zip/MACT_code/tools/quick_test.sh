#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."

echo "=============================="
echo " MCAT QUICK SANITY TEST"
echo "=============================="

if [ ! -d ".venv" ]; then
  echo "[ERR] .venv not found. Run: make venv && make deps"
  exit 1
fi
source .venv/bin/activate

python - <<'PY'
import torch
print("Python OK")
print("Torch:", torch.__version__)
print("CUDA:", torch.cuda.is_available())
print("MPS:", hasattr(torch.backends, "mps") and torch.backends.mps.is_available())
PY

DATASET=cifar10
IR=10
EPOCHS=2
BS=64

python scripts/prepare_cifar_lt.py --data_root data --dataset ${DATASET} --ir ${IR} --seed 0 || true


echo "---- [1/2] AWP quick run ----"

python run.py \
  --exp_name quick_awp \
  --dataset ${DATASET} \
  --ir ${IR} \
  --method awp \
  --arch resnet18 \
  --epochs ${EPOCHS} \
  --batch_size ${BS} \
  --train_attack_steps 2 \
  --eval_attack pgd20 \
  --eval_pgd_steps 2 \
  --eval_max_batches 2 \
  --save_every 1

echo "AWP quick test DONE"
echo

echo "---- [2/2] MCAT quick run ----"

python run.py \
  --exp_name quick_mcat \
  --dataset ${DATASET} \
  --ir ${IR} \
  --method mcat \
  --arch resnet18 \
  --epochs ${EPOCHS} \
  --batch_size ${BS} \
  --train_attack_steps 2 \
  --mspgd_steps 2 \
  --gen_epochs 1 \
  --gen_latent_steps 2 \
  --eval_attack pgd20 \
  --eval_pgd_steps 2 \
  --eval_max_batches 2 \
  --lambda_m 0.1 \
  --beta_g 0.1 \
  --save_every 1

echo "MCAT quick test DONE"
echo
echo "=============================="

