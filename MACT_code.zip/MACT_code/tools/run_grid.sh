#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."

if [ -d ".venv" ]; then
  source .venv/bin/activate
else
  echo "[warn] .venv not found. Using current python environment (OK for Colab)."
fi

DATASET=${1:-cifar100}
IRS=${2:-"10 50 100"}
SEEDS=${3:-"0 1 2"}

ARCH=${ARCH:-resnet18}
EPOCHS=${EPOCHS:-200}
BS=${BS:-128}
RUN_DIR=${RUN_DIR:-runs}
DATA_ROOT=${DATA_ROOT:-data}

EPS=${EPS:-"8/255"}
ALPHA=${ALPHA:-"2/255"}
TRAIN_STEPS=${TRAIN_STEPS:-10}
EVAL_STEPS=${EVAL_STEPS:-20}

EVAL_ATTACK=${EVAL_ATTACK:-pgd20}
EVAL_MAX_BATCHES=${EVAL_MAX_BATCHES:-0}

METHODS=${METHODS:-"clean pgd_at trades mart fast_at free_at awp mcat"}

TRADES_BETA=${TRADES_BETA:-6.0}
MART_BETA=${MART_BETA:-6.0}
FAST_ALPHA=${FAST_ALPHA:-0}
FREE_M=${FREE_M:-4}

AWP_GAMMA=${AWP_GAMMA:-0.01}
AWP_LR=${AWP_LR:-0.01}
AWP_STEPS=${AWP_STEPS:-1}

MSPGD_STEPS=${MSPGD_STEPS:-10}
MSPGD_STEP_SIZE=${MSPGD_STEP_SIZE:-"${ALPHA}"}
GEN_EPOCHS=${GEN_EPOCHS:-10}
GEN_LATENT_STEPS=${GEN_LATENT_STEPS:-5}
GEN_LATENT_LR=${GEN_LATENT_LR:-0.1}
LAMBDA_M=${LAMBDA_M:-0.2}
BETA_G=${BETA_G:-1.0}

SAVE_EVERY=${SAVE_EVERY:-50}

_run_glob() {
  local method=$1
  local dataset=$2
  local ir=$3
  local seed=$4
  echo "${RUN_DIR}/${method}_${dataset}_ir${ir}_seed${seed}_*"
}

_is_done() {
  local method=$1
  local dataset=$2
  local ir=$3
  local seed=$4

  local glob
  glob=$(_run_glob "${method}" "${dataset}" "${ir}" "${seed}")

  for d in $glob; do
    if [ -d "$d" ] && [ -f "$d/best.json" ]; then
      echo "$d"
      return 0
    fi
  done
  return 1
}

_prepare_cifar_if_needed() {
  local dataset=$1
  local ir=$2
  local seed=$3

  python scripts/prepare_cifar_lt.py \
    --data_root "${DATA_ROOT}" \
    --dataset "${dataset}" \
    --ir "${ir}" \
    --seed "${seed}" || true
}

_prepare_tiny_if_needed() {
  local ir=$1
  local seed=$2

  local tiny_root="${DATA_ROOT}/tiny-imagenet-200"
  local val_cls="${tiny_root}/val_cls"
  local train_lt="${tiny_root}/train_lt_IR${ir}_seed${seed}"

  local need=0
  if [ ! -d "${tiny_root}" ]; then
    need=1
  fi
  if [ ! -d "${val_cls}" ]; then
    need=1
  fi
  if [ ! -d "${train_lt}" ]; then
    need=1
  fi

  if [ "${need}" -eq 0 ]; then
    echo "[data] tinyimagenet OK: found ${tiny_root}, ${val_cls}, ${train_lt}"
    return 0
  fi

  echo "[data] tinyimagenet missing => preparing (IR=${ir} seed=${seed}) ..."
  echo "[data] calling: IR=${ir} SEED=${seed} bash tools/prepare_data.sh ${DATA_ROOT}"
  IR="${ir}" SEED="${seed}" bash tools/prepare_data.sh "${DATA_ROOT}"

  # final sanity
  if [ ! -d "${tiny_root}" ] || [ ! -d "${val_cls}" ] || [ ! -d "${train_lt}" ]; then
    echo "[ERR] tinyimagenet preparation did not produce expected folders:"
    echo "  tiny_root=${tiny_root}"
    echo "  val_cls=${val_cls}"
    echo "  train_lt=${train_lt}"
    exit 1
  fi
}

mkdir -p "${RUN_DIR}" "${DATA_ROOT}"

echo "=============================="
echo " RUN GRID (tools/run_grid.sh) with auto-skip + auto-data"
echo " dataset=${DATASET}"
echo " IRs=${IRS}"
echo " seeds=${SEEDS}"
echo " methods=${METHODS}"
echo " arch=${ARCH} epochs=${EPOCHS} bs=${BS}"
echo " eps=${EPS} alpha=${ALPHA} train_steps=${TRAIN_STEPS} eval_steps=${EVAL_STEPS}"
echo " eval_attack=${EVAL_ATTACK} eval_max_batches=${EVAL_MAX_BATCHES}"
echo " data_root=${DATA_ROOT}"
echo " run_dir=${RUN_DIR}"
echo "=============================="

for IR in ${IRS}; do
  for SEED in ${SEEDS}; do
    if [[ "${DATASET}" == "cifar10" || "${DATASET}" == "cifar100" ]]; then
      _prepare_cifar_if_needed "${DATASET}" "${IR}" "${SEED}"
    elif [[ "${DATASET}" == "tinyimagenet" ]]; then
      _prepare_tiny_if_needed "${IR}" "${SEED}"
    else
      echo "[ERR] Unknown dataset: ${DATASET}"
      exit 1
    fi

    for METHOD in ${METHODS}; do
      if DONE_DIR=$(_is_done "${METHOD}" "${DATASET}" "${IR}" "${SEED}"); then
        echo "---- SKIP: method=${METHOD} dataset=${DATASET} ir=${IR} seed=${SEED}"
        echo "     found best.json in: ${DONE_DIR}"
        echo
        continue
      fi

      echo "---- RUN: method=${METHOD} dataset=${DATASET} ir=${IR} seed=${SEED} ----"

      COMMON_ARGS="\
        --run_dir ${RUN_DIR} \
        --exp_name ${METHOD} \
        --seed ${SEED} \
        --dataset ${DATASET} \
        --data_root ${DATA_ROOT} \
        --ir ${IR} \
        --arch ${ARCH} \
        --epochs ${EPOCHS} \
        --batch_size ${BS} \
        --epsilon ${EPS} \
        --train_attack_steps ${TRAIN_STEPS} \
        --train_attack_step_size ${ALPHA} \
        --eval_attack ${EVAL_ATTACK} \
        --eval_pgd_steps ${EVAL_STEPS} \
        --eval_pgd_step_size ${ALPHA} \
        --eval_aa_every 0 \
        --eval_max_batches ${EVAL_MAX_BATCHES} \
        --save_every ${SAVE_EVERY}"

      EXTRA_ARGS=""
      case "${METHOD}" in
        clean)
          EXTRA_ARGS=""
          ;;
        pgd_at)
          EXTRA_ARGS=""
          ;;
        trades)
          EXTRA_ARGS="--trades_beta ${TRADES_BETA}"
          ;;
        mart)
          EXTRA_ARGS="--mart_beta ${MART_BETA}"
          ;;
        fast_at)
          EXTRA_ARGS="--fast_alpha ${FAST_ALPHA}"
          ;;
        free_at)
          EXTRA_ARGS="--free_m ${FREE_M}"
          ;;
        awp)
          EXTRA_ARGS="--awp_gamma ${AWP_GAMMA} --awp_lr ${AWP_LR} --awp_steps ${AWP_STEPS}"
          ;;
        mcat)
          EXTRA_ARGS="\
            --mspgd_steps ${MSPGD_STEPS} \
            --mspgd_step_size ${MSPGD_STEP_SIZE} \
            --mspgd_random_start \
            --gen_epochs ${GEN_EPOCHS} \
            --gen_latent_steps ${GEN_LATENT_STEPS} \
            --gen_latent_lr ${GEN_LATENT_LR} \
            --lambda_m ${LAMBDA_M} \
            --beta_g ${BETA_G}"
          ;;
        *)
          echo "[ERR] Unknown method: ${METHOD}"
          exit 1
          ;;
      esac

      python run.py --method ${METHOD} ${COMMON_ARGS} ${EXTRA_ARGS}
      echo
    done
  done
done

echo "=============================="
