import numpy as np
import torch

def per_class_accuracy(logits: torch.Tensor, y: torch.Tensor, num_classes: int):
    pred = logits.argmax(dim=1)
    correct = (pred == y).cpu().numpy().astype(np.int64)
    y_np = y.cpu().numpy().astype(np.int64)

    total = np.bincount(y_np, minlength=num_classes)
    corr = np.bincount(y_np, weights=correct, minlength=num_classes)
    acc = np.zeros(num_classes, dtype=np.float64)
    mask = total > 0
    acc[mask] = corr[mask] / total[mask]
    return acc  # per-class

def grouped_mean(acc_per_class: np.ndarray, groups: dict):
    out = {}
    for k, cls in groups.items():
        out[k] = float(np.mean(acc_per_class[cls])) if len(cls) > 0 else 0.0
    return out

def compute_ba(acc_per_class: np.ndarray):
    return float(np.mean(acc_per_class))

def compute_tail_only(acc_per_class: np.ndarray, groups: dict):
    tail = groups["tail"]
    return float(np.mean(acc_per_class[tail])) if len(tail) > 0 else 0.0
