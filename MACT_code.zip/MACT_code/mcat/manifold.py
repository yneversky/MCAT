import torch
import torch.nn as nn
import torch.nn.functional as F

class FeatureEncoder(nn.Module):
    def __init__(self, feat_dim: int, latent_dim: int, hidden: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(feat_dim, hidden),
            nn.ReLU(inplace=True),
            nn.Linear(hidden, latent_dim),
        )
    def forward(self, u):
        return self.net(u)

class MLPGenerator(nn.Module):
    def __init__(self, latent_dim: int, feat_dim: int, hidden: int, layers: int):
        super().__init__()
        assert layers >= 2
        mods = []
        d = latent_dim
        for _ in range(layers - 1):
            mods += [nn.Linear(d, hidden), nn.ReLU(inplace=True)]
            d = hidden
        mods += [nn.Linear(d, feat_dim)]
        self.net = nn.Sequential(*mods)
    def forward(self, z):
        return self.net(z)

class ClassConditionalManifolds(nn.Module):
    def __init__(self, num_classes: int, feat_dim: int, latent_dim: int,
                 enc_hidden: int, gen_hidden: int, gen_layers: int,
                 use_encoder_init: bool = True):
        super().__init__()
        self.num_classes = num_classes
        self.feat_dim = feat_dim
        self.latent_dim = latent_dim
        self.use_encoder_init = use_encoder_init

        self.encoder = FeatureEncoder(feat_dim, latent_dim, enc_hidden) if use_encoder_init else None
        self.generators = nn.ModuleList([
            MLPGenerator(latent_dim, feat_dim, gen_hidden, gen_layers)
            for _ in range(num_classes)
        ])

    def G(self, y: torch.Tensor, z: torch.Tensor) -> torch.Tensor:
        out = torch.empty((z.shape[0], self.feat_dim), device=z.device, dtype=z.dtype)
        for cls in torch.unique(y).tolist():
            m = (y == cls)
            out[m] = self.generators[cls](z[m])
        return out

    @torch.no_grad()
    def init_z(self, u: torch.Tensor) -> torch.Tensor:
        if self.encoder is None:
            return torch.randn((u.shape[0], self.latent_dim), device=u.device, dtype=u.dtype)
        return self.encoder(u)

def manifold_distance(
    u: torch.Tensor,
    y: torch.Tensor,
    manifolds: ClassConditionalManifolds,
    proj_steps: int,
    proj_lr: float,
    n_restarts: int = 1,
    detach_u: bool = False,
    detach_proj: bool = True,
):
    assert n_restarts >= 1
    B, m = u.shape
    device = u.device
    u_in = u.detach() if detach_u else u

    best = None
    for r in range(n_restarts):
        if manifolds.use_encoder_init and manifolds.encoder is not None and r == 0:
            z0 = manifolds.init_z(u_in.detach() if detach_proj else u_in)
        else:
            z0 = torch.randn((B, manifolds.latent_dim), device=device, dtype=u.dtype)

        z = z0.clone().detach().requires_grad_(True)

        for _ in range(proj_steps):
            g = manifolds.G(y, z)
            loss = (u_in.detach() if detach_proj else u_in).sub(g).pow(2).sum(dim=1).mean()
            grad = torch.autograd.grad(loss, z, create_graph=False)[0]
            z = (z - proj_lr * grad).detach().requires_grad_(True)

        g = manifolds.G(y, z.detach() if detach_proj else z)
        d = (u_in - g).pow(2).sum(dim=1)  # (B,)

        best = d if best is None else torch.minimum(best, d)

    return best  # (B,)
