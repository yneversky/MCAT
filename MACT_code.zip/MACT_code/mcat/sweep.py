import copy
import os, json, csv
from .utils import ensure_dir, set_seed
from .logger import ExperimentLogger
from .data import build_datasets
from .models import build_model
from .trainer import run_full_pipeline

def run_ir_sweep(args):
    IRs = [10, 20, 50, 100]
    base_exp = args.exp_name
    sweep_dir = os.path.join(args.runs_dir, base_exp + "_irsweep")
    ensure_dir(sweep_dir)

    rows = []
    for ir in IRs:
        a = copy.deepcopy(args)
        a.ir = ir
        a.exp_name = f"{base_exp}_ir{ir}"
        set_seed(a.seed)

        run_dir = f"{a.runs_dir}/{a.exp_name}"
        ensure_dir(run_dir)
        logger = ExperimentLogger(run_dir)
        logger.log_hparams(vars(a))

        ds = build_datasets(a.dataset, a.data_root, a.ir, a.img_size, a.batch_size, a.num_workers, a.seed)
        model = build_model(a.backbone, ds.num_classes, a.img_size, a.dataset)

        run_full_pipeline(a, ds, model, logger)
        logger.close()

        with open(os.path.join(run_dir, "summary_best.json"), "r") as f:
            s = json.load(f)

        adv_acc = s["aa"]["acc"] if s["aa"] is not None else s["pgd20"]["acc"]
        tail_adv = s["aa"]["tail"] if s["aa"] is not None else s["pgd20"]["tail"]
        rows.append([ir, s["clean"]["acc"], adv_acc, tail_adv, s["clean"]["ba"], (s["aa"]["br"] if s["aa"] else s["pgd20"]["br"])])

    out_csv = os.path.join(sweep_dir, "ir_sweep.csv")
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["IR", "CleanAcc", "AdvAcc(AA/PGD)", "TailAdv(AA/PGD)", "BA", "BR"])
        for r in rows:
            w.writerow(r)

    print(f"[IR sweep] saved: {out_csv}")
