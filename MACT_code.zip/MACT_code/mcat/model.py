import torch
import torch.nn as nn
import torchvision.models as tvm

class CIFARResNet(nn.Module):
    def __init__(self, num_classes: int, arch="resnet18"):
        super().__init__()
        if arch == "resnet18":
            m = tvm.resnet18(weights=None)
        else:
            raise ValueError(arch)
        m.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
        m.maxpool = nn.Identity()
        self.backbone = nn.Sequential(
            m.conv1, m.bn1, m.relu,
            m.layer1, m.layer2, m.layer3, m.layer4,
            m.avgpool
        )
        self.feat_dim = 512
        self.fc = nn.Linear(self.feat_dim, num_classes)

    def forward(self, x, return_feat=False):
        f = self.backbone(x)
        f = torch.flatten(f, 1)
        logits = self.fc(f)
        return (logits, f) if return_feat else logits

def build_model(backbone: str, num_classes: int, img_size: int, dataset: str):
    if dataset in ["cifar10", "cifar100"]:
        return CIFARResNet(num_classes=num_classes, arch=backbone)
    else:
        m = tvm.resnet18(weights=None)
        m.fc = nn.Linear(m.fc.in_features, num_classes)
        class Wrap(nn.Module):
            def __init__(self, net):
                super().__init__()
                self.net = net
                self.feat_dim = net.fc.in_features
            def forward(self, x, return_feat=False):
                f = None
                def hook(_, __, out):
                    nonlocal f
                    f = out
                h = self.net.avgpool.register_forward_hook(hook)
                logits = self.net(x)
                h.remove()
                f = torch.flatten(f, 1)
                return (logits, f) if return_feat else logits
        return Wrap(m)
