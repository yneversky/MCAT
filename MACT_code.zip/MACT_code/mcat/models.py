# mcat/models.py
from __future__ import annotations

from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as tvm


class ResNet18Encoder(nn.Module):
    def __init__(self, cifar_stem: bool = False):
        super().__init__()
        m = tvm.resnet18(weights=None)

        if cifar_stem:
            m.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
            m.maxpool = nn.Identity()

        self.conv1 = m.conv1
        self.bn1 = m.bn1
        self.relu = m.relu
        self.maxpool = m.maxpool
        self.layer1 = m.layer1
        self.layer2 = m.layer2
        self.layer3 = m.layer3
        self.layer4 = m.layer4
        self.avgpool = m.avgpool

        self.feat_dim = m.fc.in_features 

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        return x


class FeatClassifier(nn.Module):
    def __init__(self, encoder: nn.Module, feat_dim: int, num_classes: int):
        super().__init__()
        self.encoder = encoder
        self.classifier = nn.Linear(feat_dim, num_classes)

    def forward_features(self, x: torch.Tensor) -> torch.Tensor:
        return self.encoder(x)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        feat = self.forward_features(x)
        logits = self.classifier(feat)
        return logits, feat

    def classifier_weight(self) -> torch.Tensor:
        return self.classifier.weight


def build_model(arch: str, num_classes: int) -> nn.Module:
    arch = arch.lower()

    if arch == "resnet18":
        enc = ResNet18Encoder(cifar_stem=False)
        return FeatClassifier(enc, enc.feat_dim, num_classes)

    if arch in ("resnet18_cifar", "resnet18-cifar", "cifar_resnet18"):
        enc = ResNet18Encoder(cifar_stem=True)
        return FeatClassifier(enc, enc.feat_dim, num_classes)

    raise ValueError(f"Unknown arch: {arch}")
