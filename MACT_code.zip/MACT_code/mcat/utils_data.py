import os
import json
import numpy as np
from typing import Dict, List, Tuple


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def exp_decay_counts(num_classes: int, img_max: int, ir: int) -> List[int]:
    if num_classes <= 1:
        return [img_max]
    counts = []
    for c in range(num_classes):
        val = img_max * (ir ** (-c / (num_classes - 1)))
        counts.append(int(round(val)))
    counts = [max(1, x) for x in counts]
    for i in range(1, len(counts)):
        counts[i] = min(counts[i], counts[i - 1])
        counts[i] = max(1, counts[i])
    return counts


def make_class_groups(class_counts: List[int], head_frac=0.33, tail_frac=0.33) -> Dict[str, np.ndarray]:
    C = len(class_counts)
    order = np.argsort(-np.array(class_counts))  # desc
    n_head = int(round(C * head_frac))
    n_tail = int(round(C * tail_frac))
    head = order[:n_head]
    tail = order[-n_tail:] if n_tail > 0 else np.array([], dtype=int)
    medium = order[n_head:C - n_tail] if (C - n_head - n_tail) > 0 else np.array([], dtype=int)
    return {"head": head, "medium": medium, "tail": tail}


def stratified_subsample_indices(labels: np.ndarray, per_class_counts: List[int], seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    labels = labels.astype(int)
    C = len(per_class_counts)
    selected = []
    for c in range(C):
        idx = np.where(labels == c)[0]
        rng.shuffle(idx)
        k = min(len(idx), per_class_counts[c])
        selected.append(idx[:k])
    selected = np.concatenate(selected, axis=0)
    rng.shuffle(selected)
    return selected


def save_split_json(path: str, obj: dict):
    ensure_dir(os.path.dirname(path))
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)


def load_split_json(path: str) -> dict:
    with open(path, "r") as f:
        return json.load(f)


def k_shot_split_from_indices(indices: np.ndarray, val_ratio: float, seed: int) -> Tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    idx = indices.copy()
    rng.shuffle(idx)
    n_val = int(round(len(idx) * val_ratio))
    val_idx = idx[:n_val]
    tr_idx = idx[n_val:]
    return tr_idx, val_idx
