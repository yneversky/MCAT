from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Tuple, List, Optional

import torch
from torch.utils.data import DataLoader, Subset
from torchvision import transforms
from torchvision.datasets import CIFAR10, CIFAR100, ImageFolder


@dataclass
class DataConfig:
    dataset: str              
    data_root: str            
    ir: int
    seed: int
    batch_size: int
    num_workers: int
    tiny_train_dir: str = ""  
    tiny_val_dir: str = ""    


def _candidate_cifar_split_dirs(root: Path, dataset: str) -> List[Path]:
    """
    We support both:
      data_root/{dataset}_lt/
      data_root/{dataset}_lt_splits/
    and a few common variants.
    """
    ds = dataset.lower()
    cands = [
        root / f"{ds}_lt",
        root / f"{ds}_lt_splits",
        root / f"{ds}-lt",
        root / f"{ds}-lt-splits",
        root / f"{ds}_LT",
        root / f"{ds}_LT_splits",
    ]
    return cands


def _resolve_cifar_split_json_path(root: Path, dataset: str, ir: int, seed: int) -> Path:

    dirs = _candidate_cifar_split_dirs(root, dataset)

    name_lo = f"ir{ir}_seed{seed}.json"
    name_up = f"IR{ir}_seed{seed}.json"

    tried: List[Path] = []
    for d in dirs:
        tried.append(d / name_lo)
        tried.append(d / name_up)

    for p in tried:
        if p.exists():
            return p

    for d in dirs:
        if not d.exists() or not d.is_dir():
            continue
        target = f"ir{ir}_seed{seed}.json".lower()
        for p in d.glob("*.json"):
            if p.name.lower() == target:
                return p

    tried_str = "\n".join(f"  - {p}" for p in tried)
    raise FileNotFoundError(
        f"Missing CIFAR-LT split json for dataset={dataset}, ir={ir}, seed={seed} under root={root}.\n"
        f"Tried the following paths:\n{tried_str}\n"
        f"Suggested fix:\n"
        f"  python scripts/prepare_cifar_lt.py --data_root {root} --dataset {dataset} --ir {ir} --seed {seed}\n"
        f"Or ensure your generated file is named like '{name_lo}' (or '{name_up}') and is placed in one of:\n"
        + "\n".join(f"  - {d}" for d in dirs)
    )


def _tiny_root(root: Path) -> Path:
    if (root / "train").exists() and (root / "val").exists():
        return root
    cand = root / "tiny-imagenet-200"
    if cand.exists():
        return cand
    raise FileNotFoundError(
        f"Cannot locate tiny-imagenet-200 under {root}. "
        f"Expected either data_root=tiny-imagenet-200 or data_root containing tiny-imagenet-200/."
    )

def _cifar_train_tf() -> transforms.Compose:
    return transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
    ])


def _cifar_test_tf() -> transforms.Compose:
    return transforms.Compose([
        transforms.ToTensor(),
    ])


def _tiny_train_tf(img_size: int = 64) -> transforms.Compose:
    return transforms.Compose([
        transforms.RandomResizedCrop(img_size, scale=(0.8, 1.0)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
    ])


def _tiny_test_tf(img_size: int = 64) -> transforms.Compose:
    return transforms.Compose([
        transforms.Resize(img_size + 8),
        transforms.CenterCrop(img_size),
        transforms.ToTensor(),
    ])


def _as_int_list(x) -> List[int]:
    if x is None:
        return []
    if isinstance(x, list):
        return [int(v) for v in x]
    try:
        return [int(v) for v in list(x)]
    except Exception:
        raise ValueError(f"Cannot convert split indices to list[int], got type={type(x)}")


def _extract_train_val(obj) -> Optional[Tuple[List[int], List[int]]]:
    if not isinstance(obj, dict):
        return None

    if "train" in obj and ("val" in obj or "valid" in obj):
        return _as_int_list(obj["train"]), _as_int_list(obj.get("val", obj.get("valid")))

    if "train_idx" in obj and ("val_idx" in obj or "valid_idx" in obj):
        return _as_int_list(obj["train_idx"]), _as_int_list(obj.get("val_idx", obj.get("valid_idx")))

    if "splits" in obj and isinstance(obj["splits"], dict):
        s = obj["splits"]
        out = _extract_train_val(s)
        if out is not None:
            return out

    return None


def _load_split_indices(json_path: Path) -> Tuple[List[int], List[int]]:
    obj = json.loads(json_path.read_text(encoding="utf-8"))

    def as_int_list(x) -> List[int]:
        if x is None:
            return []
        if isinstance(x, list):
            return [int(v) for v in x]
        try:
            return [int(v) for v in list(x)]
        except Exception:
            return []

    def flatten_maybe_grouped(x) -> List[int]:
        if isinstance(x, list):
            return as_int_list(x)
        if isinstance(x, dict):
            out: List[int] = []
            keys = list(x.keys())
            try:
                keys = sorted(keys, key=lambda k: int(k))
            except Exception:
                keys = sorted(keys, key=lambda k: str(k))
            for k in keys:
                out.extend(flatten_maybe_grouped(x[k]))
            return out
        return []

    def try_common(d) -> Optional[Tuple[List[int], List[int]]]:
        if not isinstance(d, dict):
            return None

        train_keys = ["train", "train_idx", "train_indices", "trainIndex", "train_ids"]
        val_keys = ["val", "valid", "val_idx", "valid_idx", "val_indices", "valid_indices"]

        train_val = None
        for tk in train_keys:
            if tk in d:
                train_val = d[tk]
                break
        if train_val is not None:
            vval = None
            for vk in val_keys:
                if vk in d:
                    vval = d[vk]
                    break
            train_idx = flatten_maybe_grouped(train_val)
            val_idx = flatten_maybe_grouped(vval) if vval is not None else []
            if len(train_idx) > 0:
                return train_idx, val_idx

        if "splits" in d and isinstance(d["splits"], dict):
            out = try_common(d["splits"])
            if out is not None:
                return out

        return None

    out = try_common(obj)
    if out is not None:
        return out

    if isinstance(obj, list) and len(obj) > 0:
        for item in obj:
            out = try_common(item)
            if out is not None:
                return out

    if isinstance(obj, dict) and len(obj) == 1:
        only_val = next(iter(obj.values()))
        out = try_common(only_val)
        if out is not None:
            return out

    best_train: List[int] = []
    best_val: List[int] = []

    def walk(x):
        nonlocal best_train, best_val
        if isinstance(x, dict):
            candidate = try_common(x)
            if candidate is not None:
                t, v = candidate
                if len(t) > len(best_train):
                    best_train, best_val = t, v
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)

    walk(obj)

    if len(best_train) > 0:
        return best_train, best_val

    all_lists: List[List[int]] = []

    def collect_lists(x):
        if isinstance(x, list):
            lst = as_int_list(x)
            if len(lst) > 0:
                all_lists.append(lst)
            for v in x:
                collect_lists(v)
        elif isinstance(x, dict):
            for v in x.values():
                collect_lists(v)

    collect_lists(obj)
    if all_lists:
        all_lists.sort(key=len, reverse=True)
        return all_lists[0], []

    raise ValueError(f"Unknown split json schema in: {json_path}")


def build_dataloaders(cfg: DataConfig) -> Tuple[DataLoader, DataLoader, int]:
    dataset = cfg.dataset.lower()
    root = Path(cfg.data_root)

    pin = torch.cuda.is_available()

    if dataset in ("cifar10", "cifar100"):
        if dataset == "cifar10":
            base_train = CIFAR10(str(root), train=True, download=False, transform=_cifar_train_tf())
            base_val = CIFAR10(str(root), train=False, download=False, transform=_cifar_test_tf())
            num_classes = 10
        else:
            base_train = CIFAR100(str(root), train=True, download=False, transform=_cifar_train_tf())
            base_val = CIFAR100(str(root), train=False, download=False, transform=_cifar_test_tf())
            num_classes = 100

        split_json = _resolve_cifar_split_json_path(root, dataset, cfg.ir, cfg.seed)
        train_idx, _val_idx = _load_split_indices(split_json)

        train_set = Subset(base_train, train_idx)
        val_set = base_val

        train_loader = DataLoader(
            train_set,
            batch_size=cfg.batch_size,
            shuffle=True,
            num_workers=cfg.num_workers,
            pin_memory=pin,
            drop_last=True,
        )
        val_loader = DataLoader(
            val_set,
            batch_size=cfg.batch_size,
            shuffle=False,
            num_workers=cfg.num_workers,
            pin_memory=pin,
            drop_last=False,
        )
        return train_loader, val_loader, num_classes

    if dataset == "tinyimagenet":
        tiny = _tiny_root(root)

        train_dir = tiny / cfg.tiny_train_dir
        val_dir = tiny / cfg.tiny_val_dir

        if not train_dir.exists():
            raise FileNotFoundError(
                f"Missing Tiny-ImageNet-LT train dir: {train_dir}\n"
                f"Run: python scripts/prepare_tinyimagenet_lt.py --tiny_root {tiny} --ir {cfg.ir} --seed {cfg.seed}"
            )
        if not val_dir.exists():
            raise FileNotFoundError(
                f"Missing Tiny-ImageNet val_cls dir: {val_dir}\n"
                f"Run: python scripts/prepare_tinyimagenet_val.py --tiny_root {tiny}"
            )

        train_set = ImageFolder(str(train_dir), transform=_tiny_train_tf(64))
        val_set = ImageFolder(str(val_dir), transform=_tiny_test_tf(64))
        num_classes = len(train_set.classes)

        train_loader = DataLoader(
            train_set,
            batch_size=cfg.batch_size,
            shuffle=True,
            num_workers=cfg.num_workers,
            pin_memory=pin,
            drop_last=True,
        )
        val_loader = DataLoader(
            val_set,
            batch_size=cfg.batch_size,
            shuffle=False,
            num_workers=cfg.num_workers,
            pin_memory=pin,
            drop_last=False,
        )
        return train_loader, val_loader, num_classes

    raise ValueError(f"Unknown dataset: {cfg.dataset}")
