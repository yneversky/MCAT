import json
import os
from torch.utils.tensorboard import SummaryWriter
from datetime import datetime

class ExperimentLogger:
    def __init__(self, run_dir: str):
        self.run_dir = run_dir
        os.makedirs(run_dir, exist_ok=True)
        self.writer = SummaryWriter(log_dir=os.path.join(run_dir, "tb"))
        self.metrics_path = os.path.join(run_dir, "metrics.jsonl")
        self.hparams_path = os.path.join(run_dir, "hparams.json")
        self._step = 0

    def log_hparams(self, hparams: dict):
        with open(self.hparams_path, "w", encoding="utf-8") as f:
            json.dump(hparams, f, indent=2)

    def log(self, metrics: dict, step: int | None = None):
        if step is None:
            step = self._step
            self._step += 1

        for k, v in metrics.items():
            if isinstance(v, (int, float)):
                self.writer.add_scalar(k, v, step)

        rec = {"step": step, "time": datetime.now().isoformat(), **metrics}
        with open(self.metrics_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")

    def close(self):
        self.writer.flush()
        self.writer.close()
