from __future__ import annotations

import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, List

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

from mcat.data import DataConfig, build_dataloaders
from mcat.models import build_model
from mcat.attacks import pgd_linf
from mcat.awp import AWP, AWPConfig
from tqdm.auto import tqdm


@dataclass
class TrainConfig:
    exp_name: str
    out_dir: str
    seed: int

    dataset: str              
    data_root: str
    ir: int
    tiny_train_dir: str        
    tiny_val_dir: str        
    batch_size: int
    num_workers: int

    arch: str                  
    method: str               
    epochs: int
    lr: float
    weight_decay: float
    momentum: float
    device: str                
    save_every: int

    epsilon: float
    train_attack_steps: int
    train_attack_step_size: float

    eval_attack: str         
    eval_pgd_steps: int
    eval_pgd_step_size: float
    eval_aa_every: int
    eval_max_batches: int

    awp_gamma: float
    awp_lr: float
    awp_steps: int

    lambda_m: float
    beta_g: float

    mspgd_steps: int
    mspgd_step_size: float
    mspgd_random_start: bool

    gen_z_dim: int
    gen_hidden: str
    gen_epochs: int
    gen_lr: float
    gen_batch_size: int
    gen_latent_steps: int
    gen_latent_lr: float

    trades_beta: float = 6.0        
    mart_beta: float = 6.0          
    fast_alpha: float = 0.0         
    free_m: int = 4                 

    ckpt_path: Optional[str] = None
    eval_only: bool = False
    clean_ckpt_path: Optional[str] = None



def _select_device(device: str) -> torch.device:
    if device == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")
    return torch.device(device)


def _jsonl_append(path: Path, row: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def _set_seed(seed: int) -> None:
    import random
    import numpy as np
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def _nanmean(xs: List[float]) -> float:
    vals = [x for x in xs if not (isinstance(x, float) and math.isnan(x))]
    if not vals:
        return 0.0
    return float(sum(vals) / len(vals))


def _forward_logits(model: nn.Module, x: torch.Tensor) -> torch.Tensor:
    out = model(x)
    if isinstance(out, (tuple, list)):
        return out[0]
    return out


def _pgd_kl_linf(
    model: nn.Module,
    x: torch.Tensor,
    logits_ref: torch.Tensor,
    epsilon: float,
    step_size: float,
    steps: int,
    random_start: bool = True,
) -> torch.Tensor:
    was_training = model.training
    model.eval()

    x0 = x.detach()
    if random_start:
        x_adv = (x0 + torch.empty_like(x0).uniform_(-epsilon, epsilon)).clamp(0.0, 1.0).detach()
    else:
        x_adv = x0.clone().detach()

    p_ref = F.softmax(logits_ref.detach(), dim=1)

    for _ in range(steps):
        x_adv.requires_grad_(True)
        logits_adv = _forward_logits(model, x_adv)

        logp_adv = F.log_softmax(logits_adv, dim=1)
        loss_kl = F.kl_div(logp_adv, p_ref, reduction="batchmean")

        grad = torch.autograd.grad(loss_kl, x_adv, only_inputs=True)[0]
        x_adv = x_adv.detach() + step_size * grad.sign()
        x_adv = torch.max(torch.min(x_adv, x0 + epsilon), x0 - epsilon)
        x_adv = x_adv.clamp(0.0, 1.0).detach()

    if was_training:
        model.train()
    else:
        model.eval()
    return x_adv


def _fgsm_rs_linf(
    model: nn.Module,
    x: torch.Tensor,
    y: torch.Tensor,
    epsilon: float,
    alpha: float,
    random_start: bool = True,
) -> torch.Tensor:
    was_training = model.training
    model.eval()

    x0 = x.detach()
    if random_start:
        x_adv = (x0 + torch.empty_like(x0).uniform_(-epsilon, epsilon)).clamp(0.0, 1.0).detach()
    else:
        x_adv = x0.clone().detach()

    x_adv.requires_grad_(True)
    logits_adv = _forward_logits(model, x_adv)
    loss = F.cross_entropy(logits_adv, y, reduction="mean")
    grad = torch.autograd.grad(loss, x_adv, only_inputs=True)[0]

    x_adv = x_adv.detach() + alpha * grad.sign()
    x_adv = torch.max(torch.min(x_adv, x0 + epsilon), x0 - epsilon)
    x_adv = x_adv.clamp(0.0, 1.0).detach()

    if was_training:
        model.train()
    else:
        model.eval()
    return x_adv


def _split_groups_by_counts(counts: List[int]) -> Dict[str, List[int]]:
    head, med, tail = [], [], []
    for c, n in enumerate(counts):
        if n >= 100:
            head.append(c)
        elif n >= 20:
            med.append(c)
        else:
            tail.append(c)
    return {"head": head, "medium": med, "tail": tail}


@torch.no_grad()
def _per_class_accuracy(pred: torch.Tensor, y: torch.Tensor, num_classes: int) -> List[float]:
    acc = []
    for c in range(num_classes):
        mask = (y == c)
        if int(mask.sum().item()) == 0:
            acc.append(float("nan"))
        else:
            acc.append(float((pred[mask] == y[mask]).float().mean().item()))
    return acc


class MLPGenerator(nn.Module):
    def __init__(self, z_dim: int, out_dim: int, hidden: List[int]):
        super().__init__()
        layers: List[nn.Module] = []
        in_dim = z_dim
        for h in hidden:
            layers.append(nn.Linear(in_dim, h))
            layers.append(nn.ReLU(inplace=True))
            in_dim = h
        layers.append(nn.Linear(in_dim, out_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        return self.net(z)


class ClassConditionalGenerators(nn.Module):
    def __init__(self, num_classes: int, z_dim: int, feat_dim: int, hidden: List[int]):
        super().__init__()
        self.num_classes = num_classes
        self.z_dim = z_dim
        self.feat_dim = feat_dim
        self.hidden = hidden
        self.G = nn.ModuleList([MLPGenerator(z_dim, feat_dim, hidden) for _ in range(num_classes)])


class Trainer:
    def __init__(self, cfg: TrainConfig):
        self.cfg = cfg
        _set_seed(cfg.seed)

        self.out_dir = Path(cfg.out_dir)
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.device = _select_device(cfg.device)

        self.metrics_path = self.out_dir / "metrics.jsonl"
        self.env_path = self.out_dir / "env.json"
        self._write_env()

        self.train_loader, self.val_loader, self.num_classes, self.train_class_counts = self._build_dataloaders()
        self.groups = _split_groups_by_counts(self.train_class_counts)

        self.model = build_model(cfg.arch, num_classes=self.num_classes).to(self.device)

        if (cfg.clean_ckpt_path is not None) and (not cfg.eval_only):
            self._load_ckpt_weights_only(cfg.clean_ckpt_path)

        self.feat_dim = self._infer_feat_dim()

        self.generators: Optional[ClassConditionalGenerators] = None
        if cfg.method == "mcat":
            self.generators = self._init_or_load_generators()

        self.optimizer = torch.optim.SGD(
            self.model.parameters(),
            lr=cfg.lr,
            momentum=cfg.momentum,
            weight_decay=cfg.weight_decay,
        )

        self.awp: Optional[AWP] = None
        if cfg.method == "awp":
            self.awp = AWP(
                self.model,
                AWPConfig(gamma=cfg.awp_gamma, awp_lr=cfg.awp_lr, awp_steps=cfg.awp_steps),
            )

        self._free_delta: Optional[torch.Tensor] = None

        if cfg.ckpt_path and (not cfg.eval_only):
            self._load_ckpt(cfg.ckpt_path)

    def _build_dataloaders(self) -> Tuple[DataLoader, DataLoader, int, List[int]]:
        dcfg = DataConfig(
            dataset=self.cfg.dataset,
            data_root=self.cfg.data_root,
            ir=self.cfg.ir,
            seed=self.cfg.seed,
            batch_size=self.cfg.batch_size,
            num_workers=self.cfg.num_workers,
            tiny_train_dir=self.cfg.tiny_train_dir,
            tiny_val_dir=self.cfg.tiny_val_dir,
        )
        train_loader, val_loader, num_classes = build_dataloaders(dcfg)

        counts = [0 for _ in range(num_classes)]
        ds = train_loader.dataset
        if hasattr(ds, "dataset") and hasattr(ds, "indices"):
            base = ds.dataset
            idxs = ds.indices
            for i in idxs:
                _, y = base[i]
                counts[int(y)] += 1
        else:
            if hasattr(ds, "targets"):
                for y in ds.targets:
                    counts[int(y)] += 1
            elif hasattr(ds, "samples"):
                for _, y in ds.samples:
                    counts[int(y)] += 1
            else:
                for _, y in ds:
                    counts[int(y)] += 1

        return train_loader, val_loader, num_classes, counts

    def _infer_feat_dim(self) -> int:
        self.model.eval()
        x, _ = next(iter(self.train_loader))
        x = x.to(self.device)
        with torch.no_grad():
            _, feat = self.model(x)
        return int(feat.shape[1])

    def _classifier_weight(self) -> torch.Tensor:
        if hasattr(self.model, "classifier_weight"):
            return self.model.classifier_weight()
        raise RuntimeError("Model does not expose classifier_weight().")

    def _gen_ckpt_path(self) -> Path:
        return self.out_dir / "generators.pth"

    def _parse_hidden(self) -> List[int]:
        s = (self.cfg.gen_hidden or "").strip()
        if not s:
            return [256, 256]
        return [int(x.strip()) for x in s.split(",") if x.strip()]

    def _init_or_load_generators(self) -> ClassConditionalGenerators:
        hidden = self._parse_hidden()
        gens = ClassConditionalGenerators(
            num_classes=self.num_classes,
            z_dim=self.cfg.gen_z_dim,
            feat_dim=self.feat_dim,
            hidden=hidden,
        ).to(self.device)

        gen_path = self._gen_ckpt_path()
        if gen_path.exists():
            obj = torch.load(gen_path, map_location="cpu")
            gens.load_state_dict(obj["generators"], strict=True)
            for p in gens.parameters():
                p.requires_grad_(False)
            gens.eval()
            return gens

        self._train_generators(gens)
        torch.save({"generators": gens.state_dict(), "cfg": self.cfg.__dict__}, gen_path)

        for p in gens.parameters():
            p.requires_grad_(False)
        gens.eval()
        return gens

    @torch.no_grad()
    def _extract_features_batch(self, x: torch.Tensor) -> torch.Tensor:
        was_training = self.model.training
        self.model.eval()
        _, feat = self.model(x)
        if was_training:
            self.model.train()
        return feat

    def _train_generators(self, gens: ClassConditionalGenerators) -> None:
        gens.train()

        prev_req = [p.requires_grad for p in self.model.parameters()]
        for p in self.model.parameters():
            p.requires_grad_(False)

        opt = torch.optim.Adam(gens.parameters(), lr=self.cfg.gen_lr)

        for ge in range(1, self.cfg.gen_epochs + 1):
            total_loss = 0.0
            total_n = 0

            for x, y in self.train_loader:
                x = x.to(self.device, non_blocking=True)
                y = y.to(self.device, non_blocking=True)

                with torch.no_grad():
                    feat = self._extract_features_batch(x)  # [B, D]

                loss = 0.0
                groups = 0
                for c in torch.unique(y).tolist():
                    c = int(c)
                    idx = (y == c).nonzero(as_tuple=False).squeeze(1)
                    if idx.numel() == 0:
                        continue
                    feat_c = feat[idx]
                    z = torch.randn((feat_c.size(0), self.cfg.gen_z_dim), device=self.device)
                    pred = gens.G[c](z)
                    loss = loss + F.mse_loss(pred, feat_c)
                    groups += 1

                if groups == 0:
                    continue

                opt.zero_grad(set_to_none=True)
                loss.backward()
                opt.step()

                total_loss += float(loss.item()) * int(x.size(0))
                total_n += int(x.size(0))

            _jsonl_append(
                self.metrics_path,
                {
                    "epoch": 0,
                    "phase": "gen",
                    "gen_epoch": ge,
                    "gen/loss": round(total_loss / max(total_n, 1), 6),
                },
            )

        for p, r in zip(self.model.parameters(), prev_req):
            p.requires_grad_(r)

        gens.eval()

    def _manifold_distance(self, feat: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        assert self.generators is not None

        B = feat.size(0)
        dist = torch.zeros((B,), device=feat.device, dtype=feat.dtype)

        for c in torch.unique(y).tolist():
            c = int(c)
            idx = (y == c).nonzero(as_tuple=False).squeeze(1)
            if idx.numel() == 0:
                continue

            target = feat[idx].detach()
            z = torch.randn((target.size(0), self.cfg.gen_z_dim), device=feat.device, dtype=feat.dtype)
            z.requires_grad_(True)

            for _ in range(self.cfg.gen_latent_steps):
                pred = self.generators.G[c](z)
                loss = ((pred - target) ** 2).sum(dim=1).mean()
                grad = torch.autograd.grad(loss, z, only_inputs=True)[0]
                with torch.no_grad():
                    z -= self.cfg.gen_latent_lr * grad
                z.requires_grad_(True)

            with torch.no_grad():
                pred = self.generators.G[c](z)
                d = ((pred - target) ** 2).sum(dim=1)
                dist[idx] = d

        return dist

    def _geom_regularizer(self) -> torch.Tensor:
        W = self._classifier_weight()
        Wn = F.normalize(W, dim=1)
        gram = Wn @ Wn.t()
        C = gram.size(0)
        off = -1.0 / float(C - 1)
        target = torch.full_like(gram, off)
        target.fill_diagonal_(1.0)
        return F.mse_loss(gram, target)

    def _mspgd_linf(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        assert self.generators is not None

        was_training = self.model.training
        self.model.eval()

        x0 = x.detach()
        if self.cfg.mspgd_random_start:
            delta = torch.empty_like(x0).uniform_(-self.cfg.epsilon, self.cfg.epsilon)
        else:
            delta = torch.zeros_like(x0)

        x_adv = (x0 + delta).clamp(0.0, 1.0).detach()

        for _ in range(self.cfg.mspgd_steps):
            x_adv.requires_grad_(True)
            logits, feat_adv = self.model(x_adv)

            loss_ce = F.cross_entropy(logits, y)
            d = self._manifold_distance(feat_adv, y).mean()

            obj = loss_ce - self.cfg.lambda_m * d
            grad = torch.autograd.grad(obj, x_adv, only_inputs=True)[0]

            x_adv = x_adv.detach() + self.cfg.mspgd_step_size * grad.sign()
            x_adv = torch.max(torch.min(x_adv, x0 + self.cfg.epsilon), x0 - self.cfg.epsilon)
            x_adv = x_adv.clamp(0.0, 1.0).detach()

        if was_training:
            self.model.train()
        else:
            self.model.eval()

        return x_adv

    def train(self) -> Dict[str, Any]:
        best_metric = -1.0
        best_path: Optional[str] = None

        for epoch in range(1, self.cfg.epochs + 1):
            t0 = time.time()
            train_stats = self._train_one_epoch(epoch)
            eval_stats = self._evaluate_epoch(epoch)

            row = {"epoch": epoch, "time": round(time.time() - t0, 2)}
            row.update({f"train/{k}": v for k, v in train_stats.items()})
            row.update({f"eval/{k}": v for k, v in eval_stats.items()})
            _jsonl_append(self.metrics_path, row)

            metric_key = "robust_aa" if (self.cfg.eval_attack == "aa") else "robust_pgd"
            metric_val = eval_stats.get(metric_key, None)
            metric_val_f = float(metric_val) if metric_val is not None else float(eval_stats.get("robust_pgd", 0.0))

            if metric_val_f > best_metric:
                best_metric = metric_val_f
                best_path = str(self._save_ckpt("ckpt_best.pth", epoch))

            if epoch % self.cfg.save_every == 0:
                self._save_ckpt("ckpt_last.pth", epoch)

        last_path = str(self._save_ckpt("ckpt_last.pth", self.cfg.epochs))
        return {"best_metric": best_metric, "best_ckpt": best_path, "last_ckpt": last_path}

    def evaluate(self, ckpt_path: str) -> Dict[str, Any]:
        self._load_ckpt(ckpt_path)
        stats = self._evaluate_epoch(epoch=0)
        return {"ckpt": ckpt_path, **stats}

    def _train_one_epoch(self, epoch: int) -> Dict[str, Any]:
        self.model.train()

        total_loss = 0.0
        total_correct = 0
        total_n = 0

        total_geom = 0.0
        total_drift = 0.0

        pbar = tqdm(
            self.train_loader,
            desc=f"Train[{self.cfg.method}] {epoch}/{self.cfg.epochs}",
            leave=True,  
            dynamic_ncols=True,
        )

        for x, y in pbar:
            x = x.to(self.device, non_blocking=True)
            y = y.to(self.device, non_blocking=True)

            logits_for_acc: torch.Tensor

            if self.cfg.method == "clean":
                self.optimizer.zero_grad(set_to_none=True)
                logits, _ = self.model(x)
                loss = F.cross_entropy(logits, y)
                loss.backward()
                self.optimizer.step()
                logits_for_acc = logits

            elif self.cfg.method == "mcat":
                assert self.generators is not None

                x_adv = self._mspgd_linf(x, y)

                self.optimizer.zero_grad(set_to_none=True)
                logits_adv, feat_adv = self.model(x_adv)
                loss_ce = F.cross_entropy(logits_adv, y)

                loss_geom = self._geom_regularizer()
                loss = loss_ce + self.cfg.beta_g * loss_geom
                loss.backward()
                self.optimizer.step()

                was_training = self.model.training
                self.model.eval()

                with torch.no_grad():
                    _, feat_clean = self.model(x)
                    _, feat_adv2 = self.model(x_adv)

                with torch.enable_grad():
                    d_clean = self._manifold_distance(feat_clean, y).mean()
                    d_adv = self._manifold_distance(feat_adv2, y).mean()

                total_drift += float((d_adv - d_clean).item()) * int(x.size(0))
                if was_training:
                    self.model.train()

                total_geom += float(loss_geom.item()) * int(x.size(0))
                logits_for_acc = logits_adv

            else:
                raise ValueError(f"Unknown method: {self.cfg.method}")

            total_loss += float(loss.item()) * int(x.size(0))
            total_correct += int((logits_for_acc.argmax(dim=1) == y).sum().item())
            total_n += int(x.size(0))

            cur_loss = total_loss / max(total_n, 1)
            cur_acc = 100.0 * total_correct / max(total_n, 1)
            post = {"loss": f"{cur_loss:.4f}", "acc": f"{cur_acc:.2f}"}
            if self.cfg.method == "mcat":
                post["geom"] = f"{(total_geom / max(total_n, 1)):.4f}"
                post["drift"] = f"{(total_drift / max(total_n, 1)):.4f}"
            pbar.set_postfix(post)

        epoch_loss = total_loss / max(total_n, 1)
        epoch_acc = 100.0 * total_correct / max(total_n, 1)

        out: Dict[str, Any] = {
            "loss": round(epoch_loss, 6),
            "acc_adv": round(epoch_acc, 2),
        }
        if self.cfg.method == "mcat":
            out["geom_loss"] = round(total_geom / max(total_n, 1), 6)
            out["drift"] = round(total_drift / max(total_n, 1), 6)

        msg = f"[train] epoch {epoch}/{self.cfg.epochs} method={self.cfg.method} loss={out['loss']:.6f} acc={out['acc_adv']:.2f}"
        if self.cfg.method == "mcat":
            msg += f" geom={out['geom_loss']:.6f} drift={out['drift']:.6f}"
        tqdm.write(msg)

        return out

    def _iter_eval_batches(self):
        if self.cfg.eval_max_batches and self.cfg.eval_max_batches > 0:
            n = 0
            for batch in self.val_loader:
                yield batch
                n += 1
                if n >= self.cfg.eval_max_batches:
                    break
        else:
            yield from self.val_loader

    @torch.no_grad()
    def _eval_clean(self) -> Dict[str, Any]:
        self.model.eval()
        all_pred, all_y = [], []
        for x, y in self._iter_eval_batches():
            x = x.to(self.device, non_blocking=True)
            y = y.to(self.device, non_blocking=True)
            logits, _ = self.model(x)
            all_pred.append(logits.argmax(dim=1).detach().cpu())
            all_y.append(y.detach().cpu())

        pred = torch.cat(all_pred, dim=0)
        yy = torch.cat(all_y, dim=0)

        per_cls = _per_class_accuracy(pred, yy, self.num_classes)
        BA = _nanmean(per_cls)

        return {
            "clean_acc": round(100.0 * float((pred == yy).float().mean().item()), 2),
            "BA": round(100.0 * BA, 2),
        }

    def _eval_pgd(self, steps: int, step_size: float) -> Dict[str, Any]:
        self.model.eval()
        all_pred, all_y = [], []

        for x, y in self._iter_eval_batches():
            x = x.to(self.device, non_blocking=True)
            y = y.to(self.device, non_blocking=True)

            with torch.enable_grad():
                x_adv = pgd_linf(
                    self.model, x, y,
                    epsilon=self.cfg.epsilon,
                    step_size=step_size,
                    steps=steps,
                    random_start=True,
                )

            with torch.no_grad():
                logits, _ = self.model(x_adv)

            all_pred.append(logits.argmax(dim=1).detach().cpu())
            all_y.append(y.detach().cpu())

        pred = torch.cat(all_pred, dim=0)
        yy = torch.cat(all_y, dim=0)

        per_cls = _per_class_accuracy(pred, yy, self.num_classes)
        BR = _nanmean(per_cls)

        tail_classes = set(self.groups["tail"])
        tail_mask = torch.tensor([int(c in tail_classes) for c in yy.tolist()], dtype=torch.bool)
        if int(tail_mask.sum()) > 0:
            tail_acc = float((pred[tail_mask] == yy[tail_mask]).float().mean().item())
        else:
            tail_acc = 0.0

        return {
            "robust_pgd": round(100.0 * float((pred == yy).float().mean().item()), 2),
            "BR": round(100.0 * BR, 2),
            "Tail_PGD": round(100.0 * tail_acc, 2),
        }

    def _should_run_aa(self, epoch: int) -> bool:
        if self.cfg.eval_attack != "aa":
            return False
        if self.cfg.eval_aa_every <= 0:
            return epoch == self.cfg.epochs or epoch == 0
        if epoch == 0:
            return True
        if epoch % self.cfg.eval_aa_every == 0:
            return True
        if epoch == self.cfg.epochs:
            return True
        return False

    def _eval_autoattack(self) -> Optional[Dict[str, Any]]:
        try:
            from autoattack import AutoAttack
        except Exception:
            return None

        class _LogitsWrapper(nn.Module):
            def __init__(self, m: nn.Module):
                super().__init__()
                self.m = m

            def forward(self, x_in: torch.Tensor) -> torch.Tensor:
                return _forward_logits(self.m, x_in)

        was_training = self.model.training
        self.model.eval()

        wrapped = _LogitsWrapper(self.model).to(self.device)
        adversary = AutoAttack(
            wrapped, norm="Linf", eps=self.cfg.epsilon, version="standard", device=self.device
        )

        all_pred, all_y = [], []
        for x, y in self._iter_eval_batches():
            x = x.to(self.device, non_blocking=True)
            y = y.to(self.device, non_blocking=True)
            x_adv = adversary.run_standard_evaluation(x, y, bs=x.size(0))
            with torch.no_grad():
                logits, _ = self.model(x_adv)
            all_pred.append(logits.argmax(dim=1).detach().cpu())
            all_y.append(y.detach().cpu())

        if was_training:
            self.model.train()
        else:
            self.model.eval()

        pred = torch.cat(all_pred, dim=0)
        yy = torch.cat(all_y, dim=0)

        per_cls = _per_class_accuracy(pred, yy, self.num_classes)
        BR = _nanmean(per_cls)

        tail_classes = set(self.groups["tail"])
        tail_mask = torch.tensor([int(c in tail_classes) for c in yy.tolist()], dtype=torch.bool)
        if int(tail_mask.sum()) > 0:
            tail_acc = float((pred[tail_mask] == yy[tail_mask]).float().mean().item())
        else:
            tail_acc = 0.0

        return {
            "robust_aa": round(100.0 * float((pred == yy).float().mean().item()), 2),
            "BR_AA": round(100.0 * BR, 2),
            "Tail_AA": round(100.0 * tail_acc, 2),
        }

    def _evaluate_epoch(self, epoch: int) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        out.update(self._eval_clean())

        pgd_stats = self._eval_pgd(self.cfg.eval_pgd_steps, self.cfg.eval_pgd_step_size)
        out.update(pgd_stats)

        if self._should_run_aa(epoch):
            aa = self._eval_autoattack()
            if aa is None:
                out["robust_aa"] = None
                out["Tail_AA"] = None
                out["BR_AA"] = None
            else:
                out.update(aa)
        else:
            out["robust_aa"] = None
            out["Tail_AA"] = None
            out["BR_AA"] = None

        return out

    def _save_ckpt(self, name: str, epoch: int) -> Path:
        path = self.out_dir / name
        obj = {
            "epoch": epoch,
            "model": self.model.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "cfg": self.cfg.__dict__,
        }
        if self.generators is not None:
            obj["generators"] = self.generators.state_dict()
        torch.save(obj, path)
        return path

    def _load_ckpt(self, path: str) -> None:
        ckpt = torch.load(path, map_location="cpu")
        self.model.load_state_dict(ckpt["model"], strict=True)
        if "optimizer" in ckpt and ckpt["optimizer"] is not None:
            try:
                self.optimizer.load_state_dict(ckpt["optimizer"])
            except Exception:
                pass

        if self.cfg.method == "mcat":
            if self.generators is None:
                self.generators = self._init_or_load_generators()
            if "generators" in ckpt:
                try:
                    self.generators.load_state_dict(ckpt["generators"], strict=False)
                except Exception:
                    pass

    def _load_ckpt_weights_only(self, path: str) -> None:
        ckpt = torch.load(path, map_location="cpu")
        if "model" in ckpt:
            self.model.load_state_dict(ckpt["model"], strict=True)
        else:
            self.model.load_state_dict(ckpt, strict=True)

    def _write_env(self) -> None:
        env = {
            "torch": torch.__version__,
            "cuda_available": torch.cuda.is_available(),
            "mps_available": bool(getattr(torch.backends, "mps", None) and torch.backends.mps.is_available()),
        }
        self.env_path.write_text(json.dumps(env, indent=2), encoding="utf-8")
