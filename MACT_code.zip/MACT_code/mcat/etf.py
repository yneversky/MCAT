import torch
import torch.nn.functional as F

def etf_gram_target(C: int, device, dtype):
    G = torch.full((C, C), fill_value=-1.0/(C-1), device=device, dtype=dtype)
    G.fill_diagonal_(1.0)
    return G

def etf_regularizer_normalized(W: torch.Tensor):
    if W.dim() != 2:
        raise ValueError("W must be 2D")
    if W.shape[0] < W.shape[1]:
        Wc = W
    else:
        Wc = W.t()
    d, C = Wc.shape
    Wn = F.normalize(Wc, dim=0)
    G = Wn.t() @ Wn
    T = etf_gram_target(C, device=W.device, dtype=W.dtype)
    return (G - T).pow(2).mean()

def etf_regularizer_alpha_beta(W: torch.Tensor):
    if W.shape[0] < W.shape[1]:
        Wc = W
    else:
        Wc = W.t()
    d, C = Wc.shape

    G = Wc.t() @ Wc  # C x C
    diag = torch.diagonal(G)
    off = (G.sum() - diag.sum()) / (C*C - C)

    beta = off
    alpha = diag.mean() - beta

    I = torch.eye(C, device=W.device, dtype=W.dtype)
    ones = torch.ones((C, C), device=W.device, dtype=W.dtype)
    target = alpha * I + beta * ones
    return (G - target).pow(2).mean()
