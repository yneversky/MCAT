
from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


def _as_tensor_like(v: float, x: torch.Tensor) -> torch.Tensor:
    return torch.as_tensor(v, device=x.device, dtype=x.dtype)


def _clamp(x: torch.Tensor, lo: float = 0.0, hi: float = 1.0) -> torch.Tensor:
    return x.clamp(lo, hi)


def _project_linf(x_adv: torch.Tensor, x0: torch.Tensor, eps: torch.Tensor) -> torch.Tensor:
    return torch.max(torch.min(x_adv, x0 + eps), x0 - eps)


def _forward_logits(model: nn.Module, x: torch.Tensor) -> torch.Tensor:
    """
    Support both:
      - model(x) -> logits
      - model(x) -> (logits, feat)
    """
    out = model(x)
    if isinstance(out, (tuple, list)):
        return out[0]
    return out


def pgd_linf(
    model: nn.Module,
    x: torch.Tensor,
    y: torch.Tensor,
    epsilon: float,
    step_size: float,
    steps: int,
    random_start: bool = True,
    targeted: bool = False,
    y_target: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    if steps <= 0:
        return x.detach()

    if targeted and y_target is None:
        raise ValueError("targeted=True requires y_target.")

    was_training = model.training
    model.eval()

    x0 = x.detach()
    eps = _as_tensor_like(epsilon, x0)
    alpha = _as_tensor_like(step_size, x0)

    # init
    if random_start:
        delta = torch.empty_like(x0).uniform_(-1.0, 1.0) * eps
    else:
        delta = torch.zeros_like(x0)

    x_adv = _clamp(x0 + delta, 0.0, 1.0).detach()

    for _ in range(steps):
        x_adv.requires_grad_(True)

        logits = _forward_logits(model, x_adv)

        if targeted:
            loss = F.cross_entropy(logits, y_target)
            grad = torch.autograd.grad(loss, x_adv, only_inputs=True)[0]
            x_adv = x_adv.detach() - alpha * grad.sign()
        else:
            loss = F.cross_entropy(logits, y)
            grad = torch.autograd.grad(loss, x_adv, only_inputs=True)[0]
            x_adv = x_adv.detach() + alpha * grad.sign()

        x_adv = _project_linf(x_adv, x0, eps)
        x_adv = _clamp(x_adv, 0.0, 1.0).detach()

    if was_training:
        model.train()
    else:
        model.eval()

    return x_adv


def autoattack_eval(
    model: nn.Module,
    x: torch.Tensor,
    y: torch.Tensor,
    epsilon: float,
    device: torch.device,
    norm: str = "Linf",
    version: str = "standard",
) -> torch.Tensor:
    """
    Batch-wise AutoAttack (slow). For full eval, trainer loops over dataloader.

    IMPORTANT:
      AutoAttack expects model(x)->logits.
      Our model returns (logits, feat), so we wrap it.
    """
    from autoattack import AutoAttack

    class _LogitsWrapper(nn.Module):
        def __init__(self, m: nn.Module):
            super().__init__()
            self.m = m

        def forward(self, x_in: torch.Tensor) -> torch.Tensor:
            return _forward_logits(self.m, x_in)

    was_training = model.training
    model.eval()

    x = x.to(device, non_blocking=True)
    y = y.to(device, non_blocking=True)

    m = _LogitsWrapper(model).to(device)
    adversary = AutoAttack(m, norm=norm, eps=epsilon, version=version, device=device)

    x_adv = adversary.run_standard_evaluation(x, y, bs=x.size(0))

    if was_training:
        model.train()
    else:
        model.eval()

    return x_adv
