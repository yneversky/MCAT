from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class AWPConfig:
    gamma: float = 0.01      # weight perturbation scale
    awp_lr: float = 0.01     # inner ascent lr on weights
    awp_steps: int = 1       # usually 1


def _forward_logits(model: nn.Module, x: torch.Tensor) -> torch.Tensor:
    """
    Support both:
      - model(x) -> logits
      - model(x) -> (logits, feat)
    """
    out = model(x)
    if isinstance(out, (tuple, list)):
        return out[0]
    return out


class AWP:
    """
    Adversarial Weight Perturbation (Wu et al. 2020).

    Performs a small inner ascent on weights to maximize loss,
    then (outside) you train on the perturbed weights and finally restore.
    """

    def __init__(self, model: nn.Module, cfg: AWPConfig):
        self.model = model
        self.cfg = cfg
        self.backup: Dict[str, torch.Tensor] = {}

        # cache parameter refs in a stable order (important: generator yields can be re-created)
        self._param_list: List[torch.nn.Parameter] = [
            p for p in self.model.parameters() if p.requires_grad and p.dim() > 1
        ]

    def _params(self) -> List[torch.nn.Parameter]:
        return self._param_list

    @torch.no_grad()
    def _save(self) -> None:
        self.backup = {}
        for name, p in self.model.named_parameters():
            if p.requires_grad and p.dim() > 1:
                self.backup[name] = p.detach().clone()

    @torch.no_grad()
    def _restore(self) -> None:
        for name, p in self.model.named_parameters():
            if name in self.backup:
                p.copy_(self.backup[name])
        self.backup = {}

    @torch.no_grad()
    def _perturb(self) -> None:
        """
        Project the current weights back to the AWP constraint set around the saved weights:
          ||w - w0||_2 <= gamma * ||w0||_2   (applied per-parameter tensor)
        """
        for name, p in self.model.named_parameters():
            if name not in self.backup:
                continue
            w0 = self.backup[name]

            w0_norm = torch.norm(w0)
            if w0_norm.item() == 0.0:
                continue

            diff = p - w0
            diff_norm = torch.norm(diff)
            if diff_norm.item() == 0.0:
                continue

            # scale diff to have norm gamma * ||w0||
            p.copy_(w0 + (self.cfg.gamma * w0_norm) * diff / (diff_norm + 1e-12))

    def attack_step(self, x: torch.Tensor, y: torch.Tensor) -> None:
        """
        Inner ascent on weights for awp_steps:
          w <- w + awp_lr * sign(grad_w CE(f(x), y))
        then project perturbation back to the constraint set.
        """
        # Keep the original mode, but AWP is typically done in train mode.
        was_training = self.model.training
        self.model.train()

        self._save()
        params = self._params()

        for _ in range(self.cfg.awp_steps):
            logits = _forward_logits(self.model, x)
            loss = F.cross_entropy(logits, y)

            grads = torch.autograd.grad(
                loss,
                params,
                retain_graph=False,
                create_graph=False,
                allow_unused=False,
            )

            with torch.no_grad():
                for p, g in zip(params, grads):
                    # g should not be None given allow_unused=False, but be defensive
                    if g is None:
                        continue
                    p.add_(self.cfg.awp_lr * g.sign())

        self._perturb()

        if not was_training:
            self.model.eval()

    def restore(self) -> None:
        self._restore()
