from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, Optional, Tuple


def _read_json(p: Path) -> Dict[str, Any]:
    return json.loads(p.read_text(encoding='utf-8'))


def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def _coerce_metrics(obj: Dict[str, Any]) -> Dict[str, Any]:
    keys = [
        'clean_acc', 'BA',
        'robust_pgd', 'BR', 'Tail_PGD',
        'robust_aa', 'BR_AA', 'Tail_AA',
    ]
    out: Dict[str, Any] = {}
    for k in keys:
        out[k] = obj.get(k, None)
    return out


def _load_best_last(out_dir: Path) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    b = out_dir / 'best.json'
    l = out_dir / 'last.json'
    best = _read_json(b) if b.exists() else None
    last = _read_json(l) if l.exists() else None
    return best, last


def _fmt(v: Any) -> str:
    if v is None:
        return '-'
    if isinstance(v, float):
        return f'{v:.2f}'
    return str(v)


def generate_report(
    runs_root: Path,
    out_dir: Path,
    best: Optional[Dict[str, Any]] = None,
    last: Optional[Dict[str, Any]] = None,
) -> None:
    runs_root = Path(runs_root)
    out_dir = Path(out_dir)
    _ensure_dir(out_dir)

    if best is None or last is None:
        b2, l2 = _load_best_last(out_dir)
        best = best if best is not None else b2
        last = last if last is not None else l2

    if best is None or last is None:
        raise RuntimeError('generate_report: missing best/last summaries')

    bm = _coerce_metrics(best)
    lm = _coerce_metrics(last)

    csv_path = out_dir / 'results.csv'
    fields = ['tag'] + list(bm.keys())
    with csv_path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerow({'tag': 'best', **bm})
        w.writerow({'tag': 'last', **lm})
    tex_path = out_dir / 'table_main.tex'
    lines = []
    lines.append('\\begin{table}[t]')
    lines.append('\\centering')
    lines.append('\\small')
    lines.append('\\begin{tabular}{lcccccc}')
    lines.append('\\hline')
    lines.append('Tag & Clean(\\%) & PGD(\\%) & Tail-PGD(\\%) & AA(\\%) & Tail-AA(\\%) & BA(\\%) \\\\')
    lines.append('\\hline')
    lines.append(
        'best'
        + f" & {_fmt(bm['clean_acc'])}"
        + f" & {_fmt(bm['robust_pgd'])}"
        + f" & {_fmt(bm['Tail_PGD'])}"
        + f" & {_fmt(bm['robust_aa'])}"
        + f" & {_fmt(bm['Tail_AA'])}"
        + f" & {_fmt(bm['BA'])} \\\\" 
    )
    lines.append(
        'last'
        + f" & {_fmt(lm['clean_acc'])}"
        + f" & {_fmt(lm['robust_pgd'])}"
        + f" & {_fmt(lm['Tail_PGD'])}"
        + f" & {_fmt(lm['robust_aa'])}"
        + f" & {_fmt(lm['Tail_AA'])}"
        + f" & {_fmt(lm['BA'])} \\\\" 
    )
    lines.append('\\hline')
    lines.append('\\end{tabular}')
    lines.append('\\end{table}')

    tex_path.write_text('\n'.join(lines) + '\n', encoding='utf-8')

    print(f'[report] wrote: {csv_path}')
    print(f'[report] wrote: {tex_path}')
