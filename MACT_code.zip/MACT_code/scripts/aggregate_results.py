#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

def _read_json(p: Path) -> Dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _is_number(x: Any) -> bool:
    return isinstance(x, (int, float)) and not (isinstance(x, float) and math.isnan(x))


def _mean_std(vals: List[float]) -> Tuple[float, float]:
    if not vals:
        return 0.0, 0.0
    m = sum(vals) / len(vals)
    if len(vals) == 1:
        return m, 0.0
    v = sum((x - m) ** 2 for x in vals) / (len(vals) - 1)  # sample std
    return m, math.sqrt(v)


def _fmt_mean_std(m: float, s: float, digits: int = 2) -> str:
    return f"{m:.{digits}f}±{s:.{digits}f}"


def _safe_get(d: Dict[str, Any], k: str) -> Optional[float]:
    v = d.get(k, None)
    if v is None:
        return None
    if _is_number(v):
        return float(v)
    return None


@dataclass
class RunRow:
    run_dir: Path
    dataset: str
    ir: int
    seed: int
    method: str
    tag: str 

    clean_acc: Optional[float]
    BA: Optional[float]

    robust_pgd: Optional[float]
    BR: Optional[float]
    Tail_PGD: Optional[float]

    robust_aa: Optional[float]
    BR_AA: Optional[float]
    Tail_AA: Optional[float]


def _discover_runs(run_root: Path, tag: str) -> List[RunRow]:
    rows: List[RunRow] = []

    for summ_path in run_root.rglob(f"{tag}.json"):
        if not summ_path.is_file():
            continue
        run_dir = summ_path.parent
        cfg_path = run_dir / "config.json"
        if not cfg_path.exists():
            continue

        cfg = _read_json(cfg_path)
        summ = _read_json(summ_path)

        dataset = str(cfg.get("dataset", ""))
        ir = int(cfg.get("ir", -1))
        seed = int(cfg.get("seed", -1))
        method = str(cfg.get("method", ""))

        if not dataset or ir < 0 or seed < 0 or not method:
            continue

        row = RunRow(
            run_dir=run_dir,
            dataset=dataset,
            ir=ir,
            seed=seed,
            method=method,
            tag=tag,

            clean_acc=_safe_get(summ, "clean_acc"),
            BA=_safe_get(summ, "BA"),

            robust_pgd=_safe_get(summ, "robust_pgd"),
            BR=_safe_get(summ, "BR"),
            Tail_PGD=_safe_get(summ, "Tail_PGD"),

            robust_aa=_safe_get(summ, "robust_aa"),
            BR_AA=_safe_get(summ, "BR_AA"),
            Tail_AA=_safe_get(summ, "Tail_AA"),
        )
        rows.append(row)

    return rows


def _filter_rows(
    rows: List[RunRow],
    datasets: Optional[List[str]],
    methods: Optional[List[str]],
    irs: Optional[List[int]],
    require_aa: bool,
) -> List[RunRow]:
    out: List[RunRow] = []
    for r in rows:
        if datasets and r.dataset not in datasets:
            continue
        if methods and r.method not in methods:
            continue
        if irs and r.ir not in irs:
            continue
        if require_aa:
            if r.robust_aa is None:
                continue
        out.append(r)
    return out


def _group_key(r: RunRow) -> Tuple[str, int, str]:
    return (r.dataset, r.ir, r.method)


def _aggregate(rows: List[RunRow]) -> List[Dict[str, Any]]:
    groups: Dict[Tuple[str, int, str], List[RunRow]] = {}
    for r in rows:
        groups.setdefault(_group_key(r), []).append(r)

    agg_rows: List[Dict[str, Any]] = []
    for (dataset, ir, method), rs in sorted(groups.items(), key=lambda x: (x[0][0], x[0][1], x[0][2])):
        def collect(field: str) -> List[float]:
            vals: List[float] = []
            for rr in rs:
                v = getattr(rr, field)
                if v is not None:
                    vals.append(float(v))
            return vals

        def pack(field: str, digits: int = 2) -> Tuple[Optional[str], int]:
            vals = collect(field)
            if not vals:
                return None, 0
            m, s = _mean_std(vals)
            return _fmt_mean_std(m, s, digits), len(vals)

        clean_acc_s, n_clean = pack("clean_acc")
        BA_s, n_ba = pack("BA")

        robust_pgd_s, n_rpgd = pack("robust_pgd")
        BR_s, n_br = pack("BR")
        tail_pgd_s, n_tail = pack("Tail_PGD")

        robust_aa_s, n_aa = pack("robust_aa")
        BR_AA_s, n_braa = pack("BR_AA")
        tail_aa_s, n_taa = pack("Tail_AA")

        n = max(n_clean, n_ba, n_rpgd, n_br, n_tail, n_aa, n_braa, n_taa)

        agg_rows.append({
            "dataset": dataset,
            "ir": ir,
            "method": method,
            "n": n,

            "clean_acc": clean_acc_s,
            "BA": BA_s,

            "robust_pgd": robust_pgd_s,
            "BR": BR_s,
            "Tail_PGD": tail_pgd_s,

            "robust_aa": robust_aa_s,
            "BR_AA": BR_AA_s,
            "Tail_AA": tail_aa_s,
        })

    return agg_rows

def _write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    headers = [
        "dataset", "ir", "method", "n",
        "clean_acc", "BA",
        "robust_pgd", "BR", "Tail_PGD",
        "robust_aa", "BR_AA", "Tail_AA",
    ]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=headers)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in headers})


def _escape_tex(s: str) -> str:
    return s.replace("_", "\\_" )


def _write_latex_table(path: Path, rows: List[Dict[str, Any]], caption: str, label: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    def cell(v: Any) -> str:
        if v is None or v == "":
            return "--"
        return str(v)

    lines: List[str] = []
    lines.append("\\begin{table*}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append("\\setlength{\\tabcolsep}{6pt}")
    lines.append("\\begin{tabular}{l c l c c c c c c c c}")
    lines.append("\\hline")
    lines.append("Dataset & IR & Method & Clean & BA & PGD20 & BR & Tail & AA & BR$_{AA}$ & Tail$_{AA}$ \\\\")
    lines.append("\\hline")

    for r in rows:
        lines.append(
            f"{_escape_tex(r['dataset'])} & {r['ir']} & {_escape_tex(r['method'])} & "
            f"{cell(r.get('clean_acc'))} & {cell(r.get('BA'))} & "
            f"{cell(r.get('robust_pgd'))} & {cell(r.get('BR'))} & {cell(r.get('Tail_PGD'))} & "
            f"{cell(r.get('robust_aa'))} & {cell(r.get('BR_AA'))} & {cell(r.get('Tail_AA'))} \\\\"
        )

    lines.append("\\hline")
    lines.append("\\end{tabular}")
    lines.append(f"\\caption{{{caption}}}")
    lines.append(f"\\label{{{label}}}")
    lines.append("\\end{table*}")
    lines.append("")

    path.write_text("\n".join(lines), encoding="utf-8")

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run_dir", type=str, default="runs", help="Root run directory (default: runs)")
    ap.add_argument("--tag", type=str, default="best", choices=["best", "last"], help="Aggregate best.json or last.json")
    ap.add_argument("--datasets", nargs="*", default=None, help="Optional filter, e.g., cifar10 cifar100")
    ap.add_argument("--methods", nargs="*", default=None, help="Optional filter, e.g., pgd_at trades awp mcat")
    ap.add_argument("--irs", nargs="*", default=None, help="Optional filter, e.g., 10 50 100")
    ap.add_argument("--require_aa", action="store_true", help="Only keep runs where robust_aa is present (not null)")
    ap.add_argument("--out_dir", type=str, default="runs/aggregate", help="Output directory")
    ap.add_argument("--caption", type=str, default="Aggregated results (mean$\\pm$std over seeds).")
    ap.add_argument("--label", type=str, default="tab:main_results")
    args = ap.parse_args()

    run_root = Path(args.run_dir)
    if not run_root.exists():
        raise FileNotFoundError(f"run_dir not found: {run_root}")

    irs: Optional[List[int]] = None
    if args.irs:
        irs = [int(x) for x in args.irs]

    rows = _discover_runs(run_root, tag=args.tag)
    rows = _filter_rows(
        rows,
        datasets=list(args.datasets) if args.datasets else None,
        methods=list(args.methods) if args.methods else None,
        irs=irs,
        require_aa=bool(args.require_aa),
    )

    if not rows:
        print("[aggregate] No runs found. Check --run_dir / --tag / filters.")
        return

    agg = _aggregate(rows)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    csv_path = out_dir / "results.csv"
    tex_path = out_dir / "table_main.tex"

    _write_csv(csv_path, agg)
    _write_latex_table(tex_path, agg, caption=str(args.caption), label=str(args.label))

    print(f"[aggregate] OK: {len(rows)} runs -> {len(agg)} groups")
    print(f"[aggregate] CSV : {csv_path}")
    print(f"[aggregate] TeX : {tex_path}")


if __name__ == "__main__":
    main()
