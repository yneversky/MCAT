import os, sys
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)
import os
import shutil
import argparse
import numpy as np

import os, sys
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from mcat.utils_data import exp_decay_counts, ensure_dir


def list_class_images(train_root: str):
    classes = []
    images = []
    for wnid in sorted(os.listdir(train_root)):
        cdir = os.path.join(train_root, wnid, "images")
        if not os.path.isdir(cdir):
            continue
        files = [os.path.join(cdir, f) for f in os.listdir(cdir) if f.lower().endswith(".jpeg")]
        if len(files) == 0:
            continue
        classes.append(wnid)
        images.append(sorted(files))
    return classes, images


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tiny_root", type=str, required=True, help="path to tiny-imagenet-200")
    ap.add_argument("--ir", type=int, default=100)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--copy_mode", choices=["copy", "symlink"], default="copy")
    args = ap.parse_args()

    train_root = os.path.join(args.tiny_root, "train")
    assert os.path.isdir(train_root), f"Missing {train_root}"

    classes, imgs = list_class_images(train_root)
    C = len(classes)
    if C == 0:
        raise RuntimeError("No classes found under tiny train/")

    img_max = max(len(v) for v in imgs) 
    counts = exp_decay_counts(C, img_max=img_max, ir=args.ir)

    out_root = os.path.join(args.tiny_root, f"train_lt_IR{args.ir}_seed{args.seed}")
    ensure_dir(out_root)

    rng = np.random.default_rng(args.seed)
    total = 0
    for ci, wnid in enumerate(classes):
        out_c = os.path.join(out_root, wnid)
        ensure_dir(out_c)

        files = imgs[ci].copy()
        rng.shuffle(files)
        k = min(len(files), counts[ci])
        chosen = files[:k]

        for fp in chosen:
            base = os.path.basename(fp)
            dst = os.path.join(out_c, base)
            if os.path.exists(dst):
                continue
            if args.copy_mode == "copy":
                shutil.copy2(fp, dst)
            else:
                os.symlink(fp, dst)
        total += k

    print(f"Prepared Tiny-ImageNet-LT train at: {out_root}")
    print(f"IR={args.ir}, seed={args.seed}, total_images={total}, head={counts[0]}, tail~={counts[-1]}")


if __name__ == "__main__":
    main()
