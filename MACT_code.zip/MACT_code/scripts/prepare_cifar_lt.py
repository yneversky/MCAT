import os, sys
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import argparse
import numpy as np
import torchvision
import os, sys
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from mcat.utils_data import exp_decay_counts, stratified_subsample_indices, save_split_json, ensure_dir


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=["cifar10", "cifar100"], required=True)
    ap.add_argument("--data_root", type=str, default="./data")
    ap.add_argument("--ir", type=int, default=100)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    if args.dataset == "cifar10":
        ds = torchvision.datasets.CIFAR10(args.data_root, train=True, download=True)
        C, img_max = 10, 5000
    else:
        ds = torchvision.datasets.CIFAR100(args.data_root, train=True, download=True)
        C, img_max = 100, 500

    labels = np.array(ds.targets, dtype=int)
    counts = exp_decay_counts(C, img_max=img_max, ir=args.ir)
    lt_indices = stratified_subsample_indices(labels, counts, seed=args.seed)

    split_dir = f"{args.data_root}/{args.dataset}_lt_splits"
    ensure_dir(split_dir)
    out_path = f"{split_dir}/IR{args.ir}_seed{args.seed}.json"
    save_split_json(out_path, {
        "dataset": args.dataset,
        "ir": args.ir,
        "seed": args.seed,
        "counts": counts,
        "lt_indices": lt_indices.tolist(),
    })
    print("Saved:", out_path)


if __name__ == "__main__":
    main()
