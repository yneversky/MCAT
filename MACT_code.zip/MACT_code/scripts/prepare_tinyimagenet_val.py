import os, sys
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import os
import shutil
import argparse


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tiny_root", type=str, required=True,
                    help="path to tiny-imagenet-200 (contains train/, val/, wnids.txt)")
    args = ap.parse_args()

    val_dir = os.path.join(args.tiny_root, "val")
    img_dir = os.path.join(val_dir, "images")
    ann_path = os.path.join(val_dir, "val_annotations.txt")

    out_dir = os.path.join(args.tiny_root, "val_cls")
    os.makedirs(out_dir, exist_ok=True)

    mapping = {}
    with open(ann_path, "r") as f:
        for line in f:
            parts = line.strip().split("\t")
            if len(parts) >= 2:
                mapping[parts[0]] = parts[1]

    for wnid in set(mapping.values()):
        os.makedirs(os.path.join(out_dir, wnid), exist_ok=True)

    n = 0
    for img_name, wnid in mapping.items():
        src = os.path.join(img_dir, img_name)
        dst = os.path.join(out_dir, wnid, img_name)
        if not os.path.isfile(dst):
            shutil.copy2(src, dst)
        n += 1

    print(f"Prepared val_cls at: {out_dir}  (#images={n})")


if __name__ == "__main__":
    main()
