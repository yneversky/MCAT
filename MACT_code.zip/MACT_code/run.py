#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse
import json
import platform
import random
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np


from mcat.trainer import Trainer, TrainConfig
from mcat.report import generate_report


def _now() -> str:
    return time.strftime("%Y%m%d_%H%M%S")


def _set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        torch.cuda.is_available()
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except Exception:
        pass


def _git_info(root: Path) -> Dict[str, Any]:
    def run(cmd):
        try:
            out = subprocess.check_output(cmd, cwd=str(root), stderr=subprocess.DEVNULL).decode().strip()
            return out
        except Exception:
            return None

    return {
        "git_commit": run(["git", "rev-parse", "HEAD"]),
        "git_branch": run(["git", "rev-parse", "--abbrev-ref", "HEAD"]),
        "git_dirty": run(["git", "status", "--porcelain"]) not in (None, ""),
    }


def _pip_freeze() -> Optional[str]:
    try:
        return subprocess.check_output([sys.executable, "-m", "pip", "freeze"]).decode()
    except Exception:
        return None


def _env_snapshot(project_root: Path) -> Dict[str, Any]:
    snap: Dict[str, Any] = {
        "time": _now(),
        "platform": platform.platform(),
        "python": sys.version,
        "executable": sys.executable,
        "cwd": str(Path.cwd()),
    }
    snap.update(_git_info(project_root))
    freeze = _pip_freeze()
    if freeze is not None:
        snap["pip_freeze"] = freeze
    return snap


def _write_json(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")


def _parse_float_expr(s: str) -> float:
    s = str(s).strip()
    if "/" in s:
        a, b = s.split("/", 1)
        return float(a.strip()) / float(b.strip())
    return float(s)


def _resolve_tiny_paths(dataset: str, tiny_train_dir: str, tiny_val_dir: str) -> tuple[str, str]:
    if dataset != "tinyimagenet":
        return "", ""
    return tiny_train_dir, tiny_val_dir


def _strip_ckpt_field(d: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(d)
    out.pop("ckpt", None)
    return out


def _write_best_last_and_report(
    *,
    trainer: Trainer,
    out_dir: Path,
    run_dir_root: Path,
    best_ckpt: Optional[str],
    last_ckpt: Optional[str],
) -> None:
    best_obj: Optional[Dict[str, Any]] = None
    last_obj: Optional[Dict[str, Any]] = None

    if best_ckpt:
        try:
            best_summary = trainer.evaluate(best_ckpt)
            best_obj = _strip_ckpt_field(best_summary)
            best_obj["tag"] = "best"
            _write_json(out_dir / "best.json", best_obj)
        except Exception as e:
            print(f"[report] warn: failed to evaluate best_ckpt: {e}")

    if last_ckpt:
        try:
            last_summary = trainer.evaluate(last_ckpt)
            last_obj = _strip_ckpt_field(last_summary)
            last_obj["tag"] = "last"
            _write_json(out_dir / "last.json", last_obj)
        except Exception as e:
            print(f"[report] warn: failed to evaluate last_ckpt: {e}")

    try:
        if best_obj is not None and last_obj is not None:
            generate_report(run_dir_root, out_dir, best=best_obj, last=last_obj)
            print(f"[report] OK: saved to: {out_dir}")
        else:
            generate_report(run_dir_root, out_dir)
            print(f"[report] saved (partial): {out_dir}")
    except Exception as e:
        print(f"[report] skipped: {e}")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()

    p.add_argument("--exp_name", type=str, default="mcat_exp")
    p.add_argument("--run_dir", type=str, default="runs")
    p.add_argument("--seed", type=int, default=0)

    p.add_argument("--dataset", type=str, choices=["cifar10", "cifar100", "tinyimagenet"], required=True)
    p.add_argument("--data_root", type=str, default="data")
    p.add_argument("--ir", type=int, default=100)
    p.add_argument("--tiny_train_dir", type=str, default="train_lt_IR100_seed0")
    p.add_argument("--tiny_val_dir", type=str, default="val_cls")

    p.add_argument(
        "--method",
        type=str,
        choices=["clean", "pgd_at", "fast_at", "free_at", "trades", "mart", "awp", "mcat"],
        default="mcat",
    )

    p.add_argument("--lambda_m", type=float, default=0.2)
    p.add_argument("--beta_g", type=float, default=1.0)

    p.add_argument("--trades_beta", type=float, default=6.0)
    p.add_argument("--mart_beta", type=float, default=6.0)
    p.add_argument("--fast_alpha", type=str, default="0")  # allow "8/255" etc
    p.add_argument("--free_m", type=int, default=4)

    p.add_argument("--epsilon", type=str, default="8/255")
    p.add_argument("--train_attack_steps", type=int, default=10)
    p.add_argument("--train_attack_step_size", type=str, default="2/255")

    p.add_argument("--eval_attack", type=str, choices=["pgd20", "aa"], default="aa")
    p.add_argument("--eval_pgd_steps", type=int, default=20)
    p.add_argument("--eval_pgd_step_size", type=str, default="2/255")
    p.add_argument("--eval_aa_every", type=int, default=0)
    p.add_argument("--eval_max_batches", type=int, default=0)

    p.add_argument("--arch", type=str, default="resnet18")
    p.add_argument("--epochs", type=int, default=200)
    p.add_argument("--batch_size", type=int, default=128)
    p.add_argument("--lr", type=float, default=0.1)
    p.add_argument("--weight_decay", type=float, default=5e-4)
    p.add_argument("--momentum", type=float, default=0.9)

    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--device", type=str, default="auto")
    p.add_argument("--save_every", type=int, default=10)

    p.add_argument("--awp_gamma", type=float, default=0.01)
    p.add_argument("--awp_lr", type=float, default=0.01)
    p.add_argument("--awp_steps", type=int, default=1)

    p.add_argument("--mspgd_steps", type=int, default=10)
    p.add_argument("--mspgd_step_size", type=str, default="2/255")
    p.add_argument("--mspgd_random_start", action="store_true")

    p.add_argument("--gen_z_dim", type=int, default=64)
    p.add_argument("--gen_hidden", type=str, default="256,256")
    p.add_argument("--gen_epochs", type=int, default=10)
    p.add_argument("--gen_lr", type=float, default=1e-3)
    p.add_argument("--gen_batch_size", type=int, default=256)
    p.add_argument("--gen_latent_steps", type=int, default=5)
    p.add_argument("--gen_latent_lr", type=float, default=0.1)

    p.add_argument("--clean_ckpt", type=str, default="")

    p.add_argument("--eval_only", action="store_true")
    p.add_argument("--ckpt", type=str, default="")
    p.add_argument("--report_only", action="store_true")

    return p.parse_args()


def main() -> None:
    args = parse_args()
    project_root = Path(__file__).resolve().parent
    run_dir_root = Path(args.run_dir)

    run_id = f"{args.exp_name}_{args.dataset}_ir{args.ir}_seed{args.seed}_{args.method}_{_now()}"
    out_dir = Path(args.run_dir) / run_id
    out_dir.mkdir(parents=True, exist_ok=True)

    _write_json(out_dir / "config.json", vars(args).copy())
    _write_json(out_dir / "env.json", _env_snapshot(project_root))

    if args.report_only:
        generate_report(run_dir_root, out_dir)
        print(f"[report] saved to: {out_dir}")
        return

    _set_seed(args.seed)

    eps = _parse_float_expr(args.epsilon)
    train_step = _parse_float_expr(args.train_attack_step_size)
    eval_step = _parse_float_expr(args.eval_pgd_step_size)
    mspgd_step = _parse_float_expr(args.mspgd_step_size)
    fast_alpha = _parse_float_expr(args.fast_alpha)

    tiny_train_dir, tiny_val_dir = _resolve_tiny_paths(args.dataset, args.tiny_train_dir, args.tiny_val_dir)

    cfg = TrainConfig(
        exp_name=args.exp_name,
        out_dir=str(out_dir),
        seed=int(args.seed),

        dataset=args.dataset,
        data_root=args.data_root,
        ir=int(args.ir),
        tiny_train_dir=tiny_train_dir,
        tiny_val_dir=tiny_val_dir,
        batch_size=int(args.batch_size),
        num_workers=int(args.num_workers),

        arch=args.arch,
        method=args.method,
        epochs=int(args.epochs),
        lr=float(args.lr),
        weight_decay=float(args.weight_decay),
        momentum=float(args.momentum),
        device=args.device,
        save_every=int(args.save_every),

        epsilon=float(eps),
        train_attack_steps=int(args.train_attack_steps),
        train_attack_step_size=float(train_step),

        eval_attack=args.eval_attack,
        eval_pgd_steps=int(args.eval_pgd_steps),
        eval_pgd_step_size=float(eval_step),
        eval_aa_every=int(args.eval_aa_every),
        eval_max_batches=int(args.eval_max_batches),

        awp_gamma=float(args.awp_gamma),
        awp_lr=float(args.awp_lr),
        awp_steps=int(args.awp_steps),

        lambda_m=float(args.lambda_m),
        beta_g=float(args.beta_g),

        trades_beta=float(args.trades_beta),
        mart_beta=float(args.mart_beta),
        fast_alpha=float(fast_alpha),
        free_m=int(args.free_m),

        mspgd_steps=int(args.mspgd_steps),
        mspgd_step_size=float(mspgd_step),
        mspgd_random_start=bool(args.mspgd_random_start),

        gen_z_dim=int(args.gen_z_dim),
        gen_hidden=str(args.gen_hidden),
        gen_epochs=int(args.gen_epochs),
        gen_lr=float(args.gen_lr),
        gen_batch_size=int(args.gen_batch_size),
        gen_latent_steps=int(args.gen_latent_steps),
        gen_latent_lr=float(args.gen_latent_lr),

        ckpt_path=(args.ckpt if args.ckpt else None),
        eval_only=bool(args.eval_only),
        clean_ckpt_path=(args.clean_ckpt if args.clean_ckpt else None),
    )

    _write_json(out_dir / "resolved_config.json", cfg.__dict__)

    trainer = Trainer(cfg)

    summary: Dict[str, Any] = {"run_id": run_id, "out_dir": str(out_dir)}

    if args.eval_only:
        if not args.ckpt:
            raise RuntimeError("--eval_only requires --ckpt path.")
        res = trainer.evaluate(args.ckpt)
        summary["eval"] = res
        _write_json(out_dir / "summary.json", summary)
        print(json.dumps(summary, indent=2, ensure_ascii=False))

        best_obj = dict(res)
        best_obj.pop("ckpt", None)
        best_obj["tag"] = "best"
        _write_json(out_dir / "best.json", best_obj)
        _write_json(out_dir / "last.json", best_obj)
        try:
            generate_report(run_dir_root, out_dir, best=best_obj, last=best_obj)
            print(f"[report] OK: saved to: {out_dir}")
        except Exception as e:
            print(f"[report] skipped: {e}")
        return

    res = trainer.train()
    summary["train"] = res
    _write_json(out_dir / "summary.json", summary)
    print(json.dumps(summary, indent=2, ensure_ascii=False))

    _write_best_last_and_report(
        trainer=trainer,
        out_dir=out_dir,
        run_dir_root=run_dir_root,
        best_ckpt=res.get("best_ckpt"),
        last_ckpt=res.get("last_ckpt"),
    )


if __name__ == "__main__":
    main()
